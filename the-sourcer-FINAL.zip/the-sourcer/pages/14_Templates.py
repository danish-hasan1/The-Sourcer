import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

__doc__ = None  # prevent Streamlit rendering module docstring
"""
pages/14_Templates.py — Search Templates
Pre-built role archetypes — one click loads all filters for a search.
"""
import streamlit as st
from core.auth import require_auth, load_user_session
from core.search_templates import TEMPLATES, CATEGORIES, get_templates_by_category
from components.sidebar import render_sidebar
from utils.helpers import inject_global_css

st.set_page_config(
    page_title="Templates — The Sourcer",
    page_icon="📋",
    layout="wide",
)
inject_global_css()
require_auth()

user = st.session_state.user
load_user_session(user.id)
render_sidebar()

st.markdown("""
<div style="padding:1.25rem 0 0.75rem;">
    <div style="font-size:1.5rem; font-weight:800; color:#F1F5F9;">📋 Search Templates</div>
    <div style="color:#64748B; font-size:0.85rem; margin-top:3px;">
        Pre-built search filters for common role types — one click to start sourcing.
    </div>
</div>
""", unsafe_allow_html=True)

# ── Category filter ────────────────────────────────────────────────────────────
all_cats  = ["All"] + CATEGORIES
sel_cat   = st.radio("Category", all_cats, horizontal=True, label_visibility="collapsed")
q         = st.text_input("🔎 Search templates", placeholder="e.g. engineer, sales…",
                           label_visibility="collapsed")

templates = get_templates_by_category(sel_cat)
if q.strip():
    ql = q.lower()
    templates = [t for t in templates
                 if ql in t["label"].lower()
                 or ql in t["description"].lower()
                 or any(ql in s.lower() for s in t["skills"])]

st.markdown(
    f'<div style="color:#475569; font-size:0.78rem; margin:6px 0 1rem;">'
    f'{len(templates)} templates</div>',
    unsafe_allow_html=True,
)

# ── Template grid ──────────────────────────────────────────────────────────────
cols = st.columns(3)

for i, tmpl in enumerate(templates):
    with cols[i % 3]:
        skill_pills = "".join(
            f'<span style="background:#0F172A; border:1px solid #1E293B; border-radius:999px; '
            f'padding:2px 8px; font-size:10px; color:#64748B; margin:2px;">{s}</span>'
            for s in tmpl["skills"][:6]
        )
        st.markdown(f"""
        <div style="background:#1E293B; border:1px solid #334155; border-radius:12px;
                    padding:18px; margin-bottom:12px; min-height:180px;">
            <div style="display:flex; align-items:center; gap:10px; margin-bottom:8px;">
                <span style="font-size:1.4rem;">{tmpl['icon']}</span>
                <div>
                    <div style="font-weight:700; color:#F1F5F9; font-size:0.92rem;">{tmpl['label']}</div>
                    <div style="font-size:0.68rem; color:#475569; text-transform:uppercase;
                                letter-spacing:0.08em;">{tmpl['category']}</div>
                </div>
            </div>
            <div style="color:#64748B; font-size:0.78rem; margin-bottom:10px; line-height:1.5;">
                {tmpl['description']}
            </div>
            <div style="margin-bottom:10px; display:flex; flex-wrap:wrap; gap:2px;">
                {skill_pills}
                {f'<span style="background:#0F172A;border:1px solid #1E293B;border-radius:999px;padding:2px 8px;font-size:10px;color:#475569;margin:2px;">+{len(tmpl["skills"])-6} more</span>' if len(tmpl["skills"]) > 6 else ""}
            </div>
            <div style="font-size:0.72rem; color:#334155;">
                {tmpl['seniority'].title()} · {tmpl['experience_min']}–{tmpl['experience_max']} yrs
            </div>
        </div>
        """, unsafe_allow_html=True)

        if st.button(f"🚀 Use Template", key=f"use_{tmpl['id']}", use_container_width=True):
            # Load template into search filters and go to New Search
            st.session_state.search_filters = {
                "job_titles":     tmpl["job_titles"],
                "skills":         tmpl["skills"],
                "location":       "",
                "regions":        tmpl["regions"],
                "seniority":      tmpl["seniority"],
                "experience_min": tmpl["experience_min"],
                "experience_max": tmpl["experience_max"],
                "industries":     tmpl["industries"],
                "boolean_string": tmpl["boolean_string"],
            }
            # Clear AI results so the filter form shows directly
            st.session_state.ai_results       = {"from_template": True, "template_id": tmpl["id"]}
            st.session_state.sourcing_results = None
            st.toast(f"✅ Loaded: {tmpl['label']}", icon=tmpl["icon"])
            st.switch_page("pages/04_New_Search.py")

# ── Custom template hint ───────────────────────────────────────────────────────
st.markdown("---")
st.markdown("""
<div style="background:#1E293B; border:1px solid #334155; border-radius:12px;
            padding:18px 20px; text-align:center; margin-top:0.5rem;">
    <div style="font-size:1rem; font-weight:700; color:#F1F5F9; margin-bottom:4px;">
        🎯 Don't see your role?
    </div>
    <div style="color:#64748B; font-size:0.83rem; margin-bottom:12px;">
        Paste a job description in New Search and the AI will build custom filters for you.
    </div>
</div>
""", unsafe_allow_html=True)

c1, c2, c3 = st.columns([2, 1, 2])
with c2:
    if st.button("🔍 New Search with JD", use_container_width=True, type="primary"):
        st.switch_page("pages/04_New_Search.py")
