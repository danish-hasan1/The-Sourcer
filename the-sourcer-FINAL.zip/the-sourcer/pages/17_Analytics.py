import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st
import pandas as pd
from core.auth import require_auth, load_user_session
from core.database import get_candidates, get_searches, get_outreach_log
from components.sidebar import render_sidebar
from utils.helpers import inject_global_css, empty_state, stage_color

try:
    import plotly.graph_objects as go
    import plotly.express as px
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

st.set_page_config(
    page_title="Analytics — The Sourcer",
    page_icon="📊",
    layout="wide",
)
inject_global_css()
require_auth()

user = st.session_state.user
load_user_session(user.id)
render_sidebar()

st.markdown("""
<div style="padding:1.25rem 0 0.75rem;">
    <div style="font-size:1.5rem; font-weight:800; color:#F1F5F9;">📊 Analytics</div>
    <div style="color:#64748B; font-size:0.85rem; margin-top:3px;">
        Source performance, pipeline health, and search effectiveness.
    </div>
</div>
""", unsafe_allow_html=True)

# ── Load data ──────────────────────────────────────────────────────────────────
all_candidates = get_candidates(user.id)
all_searches   = get_searches(user.id)
outreach_log   = get_outreach_log(user.id)

if not all_candidates:
    empty_state("📊", "No data yet",
                "Run searches and save candidates to see analytics here.")
    if st.button("🔍 Start Sourcing", type="primary"):
        st.switch_page("pages/04_New_Search.py")
    st.stop()

# ── Top KPI row ────────────────────────────────────────────────────────────────
total    = len(all_candidates)
scored   = [c for c in all_candidates if c.get("match_score",0) > 0]
avg_sc   = int(sum(c["match_score"] for c in scored)/len(scored)) if scored else 0
pipeline = {s: sum(1 for c in all_candidates if c.get("stage","sourced")==s)
            for s in ["sourced","reviewed","contacted","responded","interview"]}
contacted_pct = int(pipeline["contacted"]/total*100) if total else 0
interview_pct = int(pipeline["interview"]/total*100) if total else 0

k1,k2,k3,k4,k5 = st.columns(5)
for col, label, val, delta in [
    (k1, "Total Candidates", total, None),
    (k2, "Avg Match Score",  f"{avg_sc}%", None),
    (k3, "Searches Run",     len(all_searches), None),
    (k4, "Contact Rate",     f"{contacted_pct}%", None),
    (k5, "Interview Rate",   f"{interview_pct}%", None),
]:
    with col:
        st.metric(label, val)

st.markdown("---")

# ── Charts row ─────────────────────────────────────────────────────────────────
if not HAS_PLOTLY:
    st.warning("Install plotly (`pip install plotly`) to see charts. Showing tables instead.")

row1_left, row1_right = st.columns(2, gap="large")

# ── Source performance ─────────────────────────────────────────────────────────
with row1_left:
    st.markdown("#### 🌐 Candidates by Source")
    by_source = {}
    for c in all_candidates:
        src = c.get("source") or "Unknown"
        by_source[src] = by_source.get(src, 0) + 1

    # Avg score per source
    src_scores = {}
    for c in scored:
        src = c.get("source") or "Unknown"
        if src not in src_scores:
            src_scores[src] = []
        src_scores[src].append(c["match_score"])
    src_avg = {k: int(sum(v)/len(v)) for k,v in src_scores.items()}

    if HAS_PLOTLY:
        sources = list(by_source.keys())
        counts  = [by_source[s] for s in sources]
        avgs    = [src_avg.get(s,0) for s in sources]
        colors  = ["#14B8A6","#F59E0B","#A5B4FC","#F0ABFC","#86EFAC","#FCA5A5","#7DCFFF"]

        fig = go.Figure()
        fig.add_trace(go.Bar(
            name="Candidates", x=sources, y=counts,
            marker_color=colors[:len(sources)],
            yaxis="y", offsetgroup=1,
        ))
        fig.add_trace(go.Scatter(
            name="Avg Score %", x=sources, y=avgs,
            mode="lines+markers", line=dict(color="#F59E0B", width=2),
            marker=dict(size=8), yaxis="y2",
        ))
        fig.update_layout(
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#94A3B8", size=11),
            yaxis=dict(title="Candidates", gridcolor="#1E293B"),
            yaxis2=dict(title="Avg Match %", overlaying="y", side="right",
                        range=[0,100], gridcolor="rgba(0,0,0,0)"),
            legend=dict(orientation="h", y=-0.2),
            height=300, margin=dict(t=10,b=40,l=10,r=10),
            barmode="group",
        )
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar":False})
    else:
        df = pd.DataFrame([{
            "Source": s, "Candidates": by_source[s], "Avg Score": f"{src_avg.get(s,0)}%"
        } for s in by_source])
        st.dataframe(df, use_container_width=True, hide_index=True)

# ── Pipeline funnel ────────────────────────────────────────────────────────────
with row1_right:
    st.markdown("#### 🔄 Pipeline Funnel")
    stages = ["sourced","reviewed","contacted","responded","interview"]
    counts = [pipeline.get(s,0) for s in stages]

    if HAS_PLOTLY:
        fig2 = go.Figure(go.Funnel(
            y=[s.title() for s in stages],
            x=counts,
            textposition="inside",
            textinfo="value+percent initial",
            marker=dict(color=["#7DCFFF","#86EFAC","#FCD34D","#A5B4FC","#F0ABFC"]),
            connector=dict(line=dict(color="#1E293B", width=2)),
        ))
        fig2.update_layout(
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#94A3B8", size=11),
            height=300, margin=dict(t=10,b=10,l=10,r=10),
        )
        st.plotly_chart(fig2, use_container_width=True, config={"displayModeBar":False})
    else:
        for s, c in zip(stages, counts):
            pct = int(c/total*100) if total else 0
            st.markdown(f"**{s.title()}:** {c} ({pct}%)")

# ── Match score distribution ───────────────────────────────────────────────────
st.markdown("---")
row2_left, row2_right = st.columns(2, gap="large")

with row2_left:
    st.markdown("#### 🎯 Match Score Distribution")
    if scored and HAS_PLOTLY:
        score_vals = [c["match_score"] for c in scored]
        fig3 = go.Figure(go.Histogram(
            x=score_vals, nbinsx=10,
            marker_color="#14B8A6", opacity=0.8,
        ))
        fig3.update_layout(
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#94A3B8", size=11),
            xaxis=dict(title="Match Score %", gridcolor="#1E293B", range=[0,100]),
            yaxis=dict(title="Count", gridcolor="#1E293B"),
            height=260, margin=dict(t=10,b=30,l=30,r=10),
        )
        st.plotly_chart(fig3, use_container_width=True, config={"displayModeBar":False})

        # Buckets
        buckets = {"Strong (85-100)":0, "Good (65-84)":0, "Potential (45-64)":0, "Weak (<45)":0}
        for sc in score_vals:
            if sc >= 85:    buckets["Strong (85-100)"] += 1
            elif sc >= 65:  buckets["Good (65-84)"]    += 1
            elif sc >= 45:  buckets["Potential (45-64)"] += 1
            else:           buckets["Weak (<45)"]      += 1
        b1,b2,b3,b4 = st.columns(4)
        for col, (label, cnt) in zip([b1,b2,b3,b4], buckets.items()):
            with col:
                st.metric(label, cnt)
    elif not scored:
        empty_state("🎯", "No scored candidates", "Run a search with an AI key to get scores.")

with row2_right:
    st.markdown("#### 📅 Search Activity")
    if all_searches:
        # Searches over time
        search_df = pd.DataFrame([{
            "date":   s.get("created_at","")[:10],
            "name":   s.get("name","?")[:30],
            "found":  s.get("result_count",0),
        } for s in all_searches if s.get("created_at")]).sort_values("date")

        if HAS_PLOTLY and len(search_df) > 0:
            fig4 = go.Figure(go.Bar(
                x=search_df["date"], y=search_df["found"],
                marker_color="#A5B4FC", text=search_df["name"],
                textposition="none",
                hovertemplate="<b>%{text}</b><br>%{y} candidates<extra></extra>",
            ))
            fig4.update_layout(
                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                font=dict(color="#94A3B8", size=11),
                xaxis=dict(title="Date", gridcolor="#1E293B"),
                yaxis=dict(title="Candidates Found", gridcolor="#1E293B"),
                height=260, margin=dict(t=10,b=30,l=30,r=10),
            )
            st.plotly_chart(fig4, use_container_width=True, config={"displayModeBar":False})
        else:
            st.dataframe(search_df, use_container_width=True, hide_index=True)
    else:
        empty_state("📅","No search history yet")

# ── Top skills ─────────────────────────────────────────────────────────────────
st.markdown("---")
st.markdown("#### 🛠️ Top Skills Across All Candidates")
skill_counts = {}
for c in all_candidates:
    for s in (c.get("skills") or []):
        skill_counts[s] = skill_counts.get(s, 0) + 1

if skill_counts:
    top_skills = sorted(skill_counts.items(), key=lambda x: -x[1])[:20]
    skill_df   = pd.DataFrame(top_skills, columns=["Skill","Count"])
    if HAS_PLOTLY:
        fig5 = go.Figure(go.Bar(
            x=skill_df["Count"], y=skill_df["Skill"],
            orientation="h", marker_color="#F59E0B",
        ))
        fig5.update_layout(
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#94A3B8", size=11),
            xaxis=dict(gridcolor="#1E293B"),
            yaxis=dict(autorange="reversed"),
            height=400, margin=dict(t=10,b=10,l=10,r=10),
        )
        st.plotly_chart(fig5, use_container_width=True, config={"displayModeBar":False})
    else:
        st.dataframe(skill_df, use_container_width=True, hide_index=True)

# ── Outreach summary ───────────────────────────────────────────────────────────
if outreach_log:
    st.markdown("---")
    st.markdown(f"#### ✉️ Outreach Summary")
    fmt_counts = {}
    for e in outreach_log:
        fmt_counts[e.get("message_format","linkedin")] = \
            fmt_counts.get(e.get("message_format","linkedin"),0) + 1
    oc1,oc2,oc3 = st.columns(3)
    with oc1: st.metric("Total Messages Sent", len(outreach_log))
    with oc2:
        most_used = max(fmt_counts, key=fmt_counts.get) if fmt_counts else "—"
        st.metric("Most Used Format", most_used.replace("_"," ").title())
    with oc3:
        response_rate = int(pipeline["responded"]/max(pipeline["contacted"],1)*100)
        st.metric("Response Rate (est.)", f"{response_rate}%")
