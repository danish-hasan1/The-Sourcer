import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

__doc__ = None  # prevent Streamlit rendering module docstring
"""
pages/18_Bookmarklet.py — Browser Bookmarklet
One-click save any LinkedIn/GitHub/job board profile directly into The Sourcer.
Two modes:
  1. The bookmarklet itself (drag to bookmarks bar)
  2. Quick-add form that receives data from the bookmarklet via URL params
"""
import streamlit as st
import urllib.parse
from core.auth import require_auth, load_user_session, get_ai_key, get_ai_provider
from core.database import save_candidate_with_dedup, get_searches, get_jd_library
from core.ai_engine import score_candidate
from components.sidebar import render_sidebar
from utils.helpers import inject_global_css, hide_sidebar_on_auth

st.set_page_config(
    page_title="Bookmarklet — The Sourcer",
    page_icon="🔖",
    layout="wide",
)
inject_global_css()

# ── Check if this is a bookmarklet callback (URL params present) ────────────
params     = st.query_params
is_capture = bool(params.get("url") or params.get("title"))

if is_capture:
    # ── QUICK-ADD MODE: called by bookmarklet ──────────────────────────────────
    # Hide sidebar for cleaner popup-like experience
    st.markdown("""
    <style>
    [data-testid="stSidebar"]        { display: none !important; }
    [data-testid="collapsedControl"] { display: none !important; }
    #MainMenu { visibility: hidden !important; }
    footer    { visibility: hidden !important; }
    header    { visibility: hidden !important; }
    .block-container { padding-top: 1.5rem !important; max-width: 600px !important; }
    </style>
    """, unsafe_allow_html=True)

    require_auth()
    user = st.session_state.user
    load_user_session(user.id)

    # Extract data from URL params
    page_url   = params.get("url", "")
    page_title = params.get("title", "")
    page_desc  = params.get("desc", "")
    page_src   = params.get("src", "")   # hinted source (linkedin/github/etc)

    # Infer source from URL
    def _infer_source(url: str) -> tuple[str, str]:
        url_l = url.lower()
        if "linkedin.com/in/"     in url_l: return "LinkedIn",      "🔵"
        if "linkedin.com/pub/"    in url_l: return "LinkedIn",      "🔵"
        if "github.com/"          in url_l: return "GitHub",        "🐙"
        if "stackoverflow.com/"   in url_l: return "Stack Overflow","📚"
        if "naukri.com/"          in url_l: return "Naukri",        "📋"
        if "reed.co.uk/"          in url_l: return "Reed",          "📋"
        if "infojobs.net/"        in url_l: return "InfoJobs",      "📋"
        if "indeed.com/"          in url_l: return "Indeed",        "📋"
        if "xing.com/"            in url_l: return "Xing",          "📋"
        if "bayt.com/"            in url_l: return "Bayt",          "📋"
        if "stepstone."           in url_l: return "StepStone",     "📋"
        return "Web",                                                "🌐"

    source, src_icon = _infer_source(page_url)

    # Brand mini header
    st.markdown(f"""
    <div style="display:flex; align-items:center; gap:10px; margin-bottom:1.25rem;
                padding-bottom:1rem; border-bottom:1px solid #1E293B;">
        <div style="font-size:1.1rem; font-weight:800; color:#14B8A6; letter-spacing:-0.02em;">
            The<span style="color:#F59E0B;">Sourcer</span>
        </div>
        <div style="font-size:0.72rem; color:#475569;">· Quick Add Candidate</div>
    </div>
    """, unsafe_allow_html=True)

    # Show captured page info
    st.markdown(f"""
    <div style="background:#1E293B; border:1px solid #334155; border-radius:10px;
                padding:12px 16px; margin-bottom:1rem; font-size:0.83rem;">
        <div style="color:#475569; font-size:0.68rem; text-transform:uppercase;
                    letter-spacing:0.08em; margin-bottom:6px;">Captured from browser</div>
        <div style="color:#F1F5F9; font-weight:600; margin-bottom:3px;">
            {src_icon} {source}
        </div>
        <div style="color:#94A3B8; font-size:0.78rem; word-break:break-all;">
            {page_url[:80] + "…" if len(page_url) > 80 else page_url}
        </div>
    </div>
    """, unsafe_allow_html=True)

    # Editable candidate form
    with st.form("quick_add_form"):
        c1, c2 = st.columns(2)
        with c1:
            name  = st.text_input("Full Name *",
                value=page_title.split(" - ")[0].split(" | ")[0].strip()[:60] if page_title else "",
                placeholder="Candidate's full name")
        with c2:
            title = st.text_input("Current Title",
                value=page_title.split(" - ")[1].strip()[:80] if " - " in page_title else "",
                placeholder="e.g. Senior Engineer at Acme")

        c3, c4 = st.columns(2)
        with c3:
            location = st.text_input("Location", placeholder="City, Country")
        with c4:
            email = st.text_input("Email (optional)", placeholder="candidate@email.com")

        skills_raw = st.text_input(
            "Skills (comma-separated)",
            placeholder="Python, React, AWS…",
        )
        notes = st.text_area("Notes", height=70,
                             placeholder="Quick notes about this candidate…")

        # Link to search
        searches = get_searches(user.id)
        s_opts   = {"— No search —": None}
        for s in searches[:8]:
            s_opts[s.get("name","?")] = s.get("id")
        sel_search = st.selectbox("Add to search", list(s_opts.keys()),
                                   label_visibility="visible")

        submitted = st.form_submit_button(
            "💾 Save to The Sourcer", type="primary", use_container_width=True
        )

    if submitted:
        if not name.strip():
            st.error("Name is required.")
        else:
            skills_list = [s.strip() for s in skills_raw.split(",") if s.strip()] if skills_raw else []
            candidate = {
                "full_name":     name.strip(),
                "current_title": title.strip(),
                "location":      location.strip(),
                "email":         email.strip(),
                "source":        source,
                "profile_url":   page_url,
                "skills":        skills_list,
                "summary":       page_desc[:500] if page_desc else "",
                "notes":         notes.strip(),
                "match_score":   0,
                "stage":         "sourced",
                "raw_data":      {"bookmarklet": True, "page_title": page_title},
            }

            result = save_candidate_with_dedup(
                user.id, candidate,
                search_id=s_opts.get(sel_search),
            )

            if result["status"] == "saved":
                st.success(f"✅ {name} saved to The Sourcer!")
                st.markdown("""
                <div style="text-align:center; padding:1rem 0; color:#64748B; font-size:0.82rem;">
                    You can close this tab and return to your browser.
                </div>
                """, unsafe_allow_html=True)
            elif result["status"] == "duplicate":
                ex = result["existing"]
                st.warning(
                    f"⚠️ **{name}** is already in your database "
                    f"(stage: {ex.get('stage','sourced').title()})."
                )
                if st.button("Save Anyway"):
                    save_candidate_with_dedup(user.id, candidate,
                                               search_id=s_opts.get(sel_search), force=True)
                    st.success("Saved!")
            else:
                st.error("Save failed — please try again.")

    # Open in full app link
    st.markdown(
        '<div style="text-align:center; margin-top:1rem;">'
        '<a href="/" style="color:#14B8A6; font-size:0.8rem; text-decoration:none;">'
        '↗ Open The Sourcer</a></div>',
        unsafe_allow_html=True,
    )
    st.stop()

# ── NORMAL MODE: bookmarklet setup page ───────────────────────────────────────
require_auth()
user = st.session_state.user
load_user_session(user.id)
render_sidebar()

st.markdown("""
<div style="padding:1.25rem 0 0.75rem;">
    <div style="font-size:1.5rem; font-weight:800; color:#F1F5F9;">🔖 Browser Bookmarklet</div>
    <div style="color:#64748B; font-size:0.85rem; margin-top:3px;">
        Save any candidate profile to The Sourcer with one click — from LinkedIn, GitHub, job boards, anywhere.
    </div>
</div>
""", unsafe_allow_html=True)

# ── Detect app URL ─────────────────────────────────────────────────────────────
# Try to determine the app's base URL for the bookmarklet
app_url = st.secrets.get("APP_URL", "")
if not app_url:
    # Try to infer from Streamlit's URL
    try:
        from streamlit.web.server.server import Server
        app_url = ""
    except Exception:
        app_url = ""

# If we can't detect, ask the user
if not app_url:
    st.markdown("""
    <div style="background:#1A2A1E; border:1px solid #166534; border-radius:10px;
                padding:14px 18px; margin-bottom:1rem;">
        <div style="color:#86EFAC; font-weight:600; font-size:0.88rem; margin-bottom:4px;">
            📌 First: confirm your app URL
        </div>
        <div style="color:#64748B; font-size:0.82rem;">
            The bookmarklet needs to know where your app lives so it can open the right page.
        </div>
    </div>
    """, unsafe_allow_html=True)
    app_url_input = st.text_input(
        "Your app URL",
        placeholder="e.g. https://the-sourcer.streamlit.app",
        help="This is the URL you use to access The Sourcer. No trailing slash.",
    )
    if app_url_input.strip():
        app_url = app_url_input.strip().rstrip("/")
else:
    app_url_input = app_url

bookmarklet_page = f"{app_url}/Bookmarklet" if app_url else "#"

# ── Build the bookmarklet JS ───────────────────────────────────────────────────
bookmarklet_js = f"""javascript:(function(){{
  var u=encodeURIComponent(location.href);
  var t=encodeURIComponent(document.title);
  var d=encodeURIComponent((document.querySelector('meta[name=description]')||{{}}).content||'');
  var src='web';
  if(location.href.indexOf('linkedin.com')>-1)src='linkedin';
  else if(location.href.indexOf('github.com')>-1)src='github';
  else if(location.href.indexOf('stackoverflow.com')>-1)src='stackoverflow';
  window.open('{bookmarklet_page}?url='+u+'&title='+t+'&desc='+d+'&src='+src,'_blank','width=560,height=700,scrollbars=yes');
}})();"""

bookmarklet_link = bookmarklet_js.replace("\n","").replace("  ","")

# ── Hero ───────────────────────────────────────────────────────────────────────
col_inst, col_demo = st.columns([3, 2], gap="large")

with col_inst:
    st.markdown("### How It Works")
    st.markdown("""
    <div style="display:flex; flex-direction:column; gap:14px; margin-bottom:1.5rem;">
        <div style="display:flex; gap:14px; align-items:flex-start;">
            <div style="background:#0D9488; color:white; border-radius:50%; width:28px; height:28px;
                        display:flex; align-items:center; justify-content:center; font-weight:800;
                        font-size:13px; flex-shrink:0; margin-top:2px;">1</div>
            <div>
                <div style="font-weight:600; color:#F1F5F9; font-size:0.88rem;">Drag the button to your bookmarks bar</div>
                <div style="color:#64748B; font-size:0.78rem; margin-top:2px;">
                    In Chrome/Firefox: drag the yellow button below to your bookmarks toolbar.<br>
                    In Safari: right-click → Add Bookmark.
                </div>
            </div>
        </div>
        <div style="display:flex; gap:14px; align-items:flex-start;">
            <div style="background:#0D9488; color:white; border-radius:50%; width:28px; height:28px;
                        display:flex; align-items:center; justify-content:center; font-weight:800;
                        font-size:13px; flex-shrink:0; margin-top:2px;">2</div>
            <div>
                <div style="font-weight:600; color:#F1F5F9; font-size:0.88rem;">Browse to any candidate profile</div>
                <div style="color:#64748B; font-size:0.78rem; margin-top:2px;">
                    LinkedIn, GitHub, Stack Overflow, Naukri, Reed, InfoJobs, Indeed — any page.
                </div>
            </div>
        </div>
        <div style="display:flex; gap:14px; align-items:flex-start;">
            <div style="background:#0D9488; color:white; border-radius:50%; width:28px; height:28px;
                        display:flex; align-items:center; justify-content:center; font-weight:800;
                        font-size:13px; flex-shrink:0; margin-top:2px;">3</div>
            <div>
                <div style="font-weight:600; color:#F1F5F9; font-size:0.88rem;">Click the bookmark</div>
                <div style="color:#64748B; font-size:0.78rem; margin-top:2px;">
                    A small popup opens pre-filled with the page URL and title.<br>
                    Add a name, title, skills, notes — then click Save.
                </div>
            </div>
        </div>
        <div style="display:flex; gap:14px; align-items:flex-start;">
            <div style="background:#F59E0B; color:#0F172A; border-radius:50%; width:28px; height:28px;
                        display:flex; align-items:center; justify-content:center; font-weight:800;
                        font-size:13px; flex-shrink:0; margin-top:2px;">✓</div>
            <div>
                <div style="font-weight:600; color:#F1F5F9; font-size:0.88rem;">Candidate is instantly in your database</div>
                <div style="color:#64748B; font-size:0.78rem; margin-top:2px;">
                    No copy-paste. No tab switching. Profile URL is saved automatically.
                </div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # ── The bookmarklet button (drag this) ─────────────────────────────────────
    if app_url:
        st.markdown("### Your Bookmarklet")
        st.markdown(f"""
        <div style="background:#1E293B; border:1px solid #334155; border-radius:12px;
                    padding:20px; text-align:center; margin-bottom:1rem;">
            <div style="color:#64748B; font-size:0.78rem; margin-bottom:14px;">
                ← Drag this button to your bookmarks bar →
            </div>
            <a href="{bookmarklet_link}"
               style="display:inline-block; background:#F59E0B; color:#0F172A;
                      font-weight:800; font-size:0.95rem; padding:10px 24px;
                      border-radius:8px; text-decoration:none; cursor:grab;
                      box-shadow:0 4px 12px rgba(245,158,11,0.3);"
               onclick="return false;">
                🔖 Save to The Sourcer
            </a>
            <div style="color:#334155; font-size:0.68rem; margin-top:12px;">
                ⚠️ Don't click — drag it to your bookmarks bar
            </div>
        </div>
        """, unsafe_allow_html=True)

        # Also show the raw JS for manual install
        with st.expander("🔧 Manual install (copy the code)", expanded=False):
            st.markdown("If drag-and-drop doesn't work in your browser:")
            st.markdown("1. Create a new bookmark manually in your browser")
            st.markdown("2. Set the **URL** field to this code:")
            st.code(bookmarklet_link, language=None)
    else:
        st.info("Enter your app URL above to generate your personal bookmarklet.")

with col_demo:
    st.markdown("### Works On These Sites")
    sites = [
        ("🔵", "LinkedIn",      "linkedin.com/in/…",       "Profile pages"),
        ("🐙", "GitHub",        "github.com/username",     "Developer profiles"),
        ("📚", "Stack Overflow", "stackoverflow.com/users/…","Expert profiles"),
        ("📋", "Naukri",        "naukri.com/…",            "Candidate profiles"),
        ("📋", "Reed",          "reed.co.uk/…",            "CV search results"),
        ("📋", "InfoJobs",      "infojobs.net/…",          "Candidate profiles"),
        ("📋", "Indeed",        "indeed.com/…",            "Resume profiles"),
        ("📋", "Bayt",          "bayt.com/…",              "Candidate profiles"),
        ("📋", "StepStone",     "stepstone.de/…",          "Candidate profiles"),
        ("🌐", "Any page",      "any URL",                 "Custom add with URL saved"),
    ]
    for icon, name, url_ex, desc in sites:
        st.markdown(f"""
        <div style="display:flex; align-items:center; gap:10px; padding:8px 12px;
                    border-left:2px solid #334155; margin-bottom:6px;">
            <span style="font-size:1rem; flex-shrink:0;">{icon}</span>
            <div>
                <div style="font-weight:600; color:#F1F5F9; font-size:0.82rem;">{name}</div>
                <div style="color:#334155; font-size:0.68rem;">{url_ex}</div>
            </div>
            <div style="margin-left:auto; font-size:0.7rem; color:#475569;">{desc}</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("""
    <div style="background:#1E293B; border-radius:10px; padding:14px 16px;">
        <div style="font-weight:600; color:#F1F5F9; font-size:0.85rem; margin-bottom:6px;">
            💡 Pro Tips
        </div>
        <div style="color:#64748B; font-size:0.78rem; line-height:1.7;">
            • Bookmarklet works on <b style="color:#94A3B8;">any device</b> — desktop Chrome, Firefox, Safari, Edge<br>
            • On mobile: add to your browser's favourites bar<br>
            • The popup stays small so you don't lose your place on the profile<br>
            • Duplicate detection warns you if you've already saved this person<br>
            • Link saved candidates to any active search for easy filtering
        </div>
    </div>
    """, unsafe_allow_html=True)

# ── Test bookmarklet ───────────────────────────────────────────────────────────
st.markdown("---")
st.markdown("### 🧪 Test It Now")
st.markdown('<div style="color:#64748B; font-size:0.82rem; margin-bottom:10px;">Simulate what happens when you click the bookmarklet on a LinkedIn profile.</div>', unsafe_allow_html=True)

test_col1, test_col2 = st.columns([2, 1])
with test_col1:
    test_url = st.text_input(
        "Paste any profile URL to test",
        placeholder="https://www.linkedin.com/in/some-candidate/",
        label_visibility="collapsed",
    )
with test_col2:
    if st.button("🔖 Simulate Bookmarklet Click", use_container_width=True,
                 type="primary", disabled=not test_url.strip()):
        encoded = urllib.parse.quote(test_url.strip())
        title   = urllib.parse.quote("Test Candidate - Software Engineer | LinkedIn")
        st.markdown(
            f'<meta http-equiv="refresh" content="0;url=/Bookmarklet?url={encoded}&title={title}">',
            unsafe_allow_html=True,
        )
        st.info(f"Opening quick-add popup for: {test_url[:60]}…")

# ── APP_URL tip ────────────────────────────────────────────────────────────────
st.markdown("---")
with st.expander("⚙️ Setting up APP_URL in Streamlit Cloud secrets", expanded=False):
    st.markdown("""
To auto-fill your app URL (so you don't have to type it each time):

1. Go to your **Streamlit Cloud app → Settings → Secrets**
2. Add this line:
```toml
APP_URL = "https://your-app-name.streamlit.app"
```
3. Save — the bookmarklet will generate automatically for all users.
    """)
