import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st
from core.auth import require_auth, load_user_session, get_ai_key, get_ai_provider
from core.ai_engine import generate_outreach
from core.database import get_candidates, save_outreach, get_jd_library
from components.sidebar import render_sidebar
from utils.helpers import inject_global_css, source_icon

st.set_page_config(
    page_title="Bulk Outreach — The Sourcer",
    page_icon="📨",
    layout="wide",
)
inject_global_css()
require_auth()

user = st.session_state.user
load_user_session(user.id)
render_sidebar()

st.markdown("""
<div style="padding:1.25rem 0 0.75rem;">
    <div style="font-size:1.5rem; font-weight:800; color:#F1F5F9;">📨 Bulk Outreach</div>
    <div style="color:#64748B; font-size:0.85rem; margin-top:3px;">
        Generate personalised messages for multiple candidates at once.
    </div>
</div>
""", unsafe_allow_html=True)

ai_key      = get_ai_key()
ai_provider = get_ai_provider()

if not ai_key:
    st.error("🔑 Add an AI API key in Settings to generate outreach messages.")
    if st.button("⚙️ Settings"):
        st.switch_page("pages/09_Settings.py")
    st.stop()

candidates = get_candidates(user.id)
if not candidates:
    st.info("No saved candidates yet. Save candidates from search results first.")
    if st.button("🔍 New Search", type="primary"):
        st.switch_page("pages/04_New_Search.py")
    st.stop()

# ── Configuration panel ────────────────────────────────────────────────────────
st.markdown("### 1 · Configure")
cfg1, cfg2, cfg3, cfg4 = st.columns([3, 2, 2, 2])

with cfg1:
    # Filter by stage
    stage_filter = st.multiselect(
        "Filter by stage",
        ["sourced","reviewed","contacted","responded","interview"],
        default=["sourced","reviewed"],
        label_visibility="collapsed",
        placeholder="All stages",
    )

with cfg2:
    fmt = st.selectbox(
        "Format",
        ["LinkedIn Connection Note","LinkedIn InMail","Email"],
        label_visibility="collapsed",
    )

with cfg3:
    tone = st.select_slider(
        "Tone",
        options=["Formal","Professional","Conversational","Casual"],
        value="Professional",
        label_visibility="collapsed",
    )

with cfg4:
    jds     = get_jd_library(user.id)
    jd_map  = {"— No JD context —": ""}
    for jd in jds:
        jd_map[jd.get("title","Untitled")] = jd.get("jd_text","")[:600]
    jd_label   = st.selectbox("JD context", list(jd_map.keys()),
                               label_visibility="collapsed")
    jd_summary = jd_map[jd_label]

# ── Candidate selection ────────────────────────────────────────────────────────
st.markdown("### 2 · Select Candidates")

filtered_cands = [c for c in candidates
                  if not stage_filter or c.get("stage","sourced") in stage_filter]

cand_map = {
    f"{c.get('full_name','Unknown')} — {c.get('current_title','')} "
    f"({source_icon(c.get('source',''))} {c.get('source','')})": c
    for c in filtered_cands
}

sel_labels = st.multiselect(
    "Choose candidates (max 10)",
    options=list(cand_map.keys()),
    max_selections=10,
    label_visibility="collapsed",
    placeholder="Select candidates to message…",
)
selected = [cand_map[l] for l in sel_labels]

st.markdown(
    f'<div style="color:#475569; font-size:0.78rem; margin-top:4px;">'
    f'{len(selected)} selected · {len(filtered_cands)} available</div>',
    unsafe_allow_html=True,
)

# ── Generate ───────────────────────────────────────────────────────────────────
FMT_MAP = {
    "LinkedIn Connection Note": "linkedin",
    "LinkedIn InMail":          "linkedin_inmail",
    "Email":                    "email",
}

gen_btn = st.button(
    f"✨ Generate {len(selected)} Message{'s' if len(selected) != 1 else ''}",
    type="primary",
    disabled=len(selected) == 0,
)

if gen_btn and selected:
    messages = {}
    prog = st.progress(0, text="Generating messages…")
    for i, c in enumerate(selected):
        prog.progress((i+1)/len(selected),
                      text=f"✍️ Writing for {c.get('full_name','?')}… ({i+1}/{len(selected)})")
        result = generate_outreach(
            provider=ai_provider,
            api_key=ai_key,
            candidate=c,
            jd_summary=jd_summary,
            tone=tone.lower(),
            fmt=FMT_MAP.get(fmt,"linkedin"),
        )
        messages[c.get("full_name","?")] = {
            "candidate": c,
            "message":   (result or {}).get("message","Generation failed."),
            "subject":   (result or {}).get("subject"),
        }
    prog.empty()
    st.session_state["bulk_messages"] = messages
    st.success(f"✅ Generated {len(messages)} personalised messages!")

# ── Review & Copy ──────────────────────────────────────────────────────────────
bulk = st.session_state.get("bulk_messages", {})
if bulk:
    st.markdown("---")
    st.markdown(f"### 3 · Review & Send — {len(bulk)} Messages")

    CHAR_LIMITS = {
        "LinkedIn Connection Note": 300,
        "LinkedIn InMail": 2000,
        "Email": None,
    }
    limit = CHAR_LIMITS.get(fmt)

    for name, data in bulk.items():
        c    = data["candidate"]
        msg  = data["message"]
        subj = data["subject"]
        url  = c.get("profile_url","")
        score = c.get("match_score",0)
        sc_c = "#10B981" if score >= 80 else "#14B8A6" if score >= 65 else "#F59E0B" if score else "#94A3B8"

        with st.expander(
            f"✉️  {name}  ·  {c.get('current_title','')}  ·  {score}% match",
            expanded=False,
        ):
            hdr1, hdr2 = st.columns([3, 1])
            with hdr1:
                if subj:
                    st.markdown(f"**Subject:** {subj}")
            with hdr2:
                st.markdown(
                    f'<div style="text-align:right; font-size:1.2rem; font-weight:800; color:{sc_c};">'
                    f'{score}%</div>',
                    unsafe_allow_html=True,
                )

            edited = st.text_area(
                "Message",
                value=msg,
                height=200,
                key=f"bulk_msg_{name}",
                label_visibility="collapsed",
            )

            if limit:
                chars  = len(edited)
                pct    = chars / limit
                mcolor = "#10B981" if pct<=0.8 else "#F59E0B" if pct<=1.0 else "#F87171"
                st.markdown(
                    f'<div style="font-size:0.72rem; color:{mcolor};">{chars}/{limit} chars</div>',
                    unsafe_allow_html=True,
                )

            ba, bb = st.columns(2)
            with ba:
                if st.button("📋 Copy", key=f"copy_{name}", use_container_width=True, type="primary"):
                    escaped = edited.replace("\\","\\\\").replace("`","\\`").replace("$","\\$")
                    st.markdown(f"<script>navigator.clipboard.writeText(`{escaped}`);</script>",
                                unsafe_allow_html=True)
                    st.toast(f"📋 Copied message for {name}!", icon="✅")
                    # Log it
                    save_outreach(
                        user_id=user.id,
                        candidate_id=c.get("id"),
                        message=edited,
                        fmt=FMT_MAP.get(fmt,"linkedin"),
                        tone=tone.lower(),
                    )
            with bb:
                if url:
                    st.link_button("🔗 Profile", url, use_container_width=True)

    # Export all as text file
    st.markdown("---")
    all_text = "\n\n" + "="*60 + "\n\n".join(
        f"TO: {n}\nFORMAT: {fmt}\n\n{d['message']}"
        for n, d in bulk.items()
    )
    st.download_button(
        "📥 Download All Messages as .txt",
        all_text,
        file_name="outreach_messages.txt",
        mime="text/plain",
    )
