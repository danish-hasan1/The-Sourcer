import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st
from core.auth import require_auth, load_user_session, get_ai_key, get_ai_provider
from core.database import get_candidates, get_jd_library
from core.ai_engine import score_candidate
from components.sidebar import render_sidebar
from utils.helpers import inject_global_css, stage_color, source_icon

try:
    import plotly.graph_objects as go
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

st.set_page_config(
    page_title="Compare Candidates — The Sourcer",
    page_icon="⚖️",
    layout="wide",
)
inject_global_css()
require_auth()

user = st.session_state.user
load_user_session(user.id)
render_sidebar()

st.markdown("""
<div style="padding:1.25rem 0 0.75rem;">
    <div style="font-size:1.5rem; font-weight:800; color:#F1F5F9;">⚖️ Compare Candidates</div>
    <div style="color:#64748B; font-size:0.85rem; margin-top:3px;">
        Select up to 4 candidates and a JD — get a side-by-side AI comparison.
    </div>
</div>
""", unsafe_allow_html=True)

ai_key      = get_ai_key()
ai_provider = get_ai_provider()
candidates  = get_candidates(user.id)
jds         = get_jd_library(user.id)

if not candidates:
    st.info("No saved candidates yet. Run a search and save some candidates first.")
    if st.button("🔍 New Search", type="primary"):
        st.switch_page("pages/04_New_Search.py")
    st.stop()

# ── Selection controls ─────────────────────────────────────────────────────────
st.markdown("### Select Candidates & JD")
sel_col, jd_col = st.columns([3, 2])

with sel_col:
    cand_options = {
        f"{c.get('full_name','Unknown')} — {c.get('current_title','')} ({source_icon(c.get('source',''))} {c.get('source','')})": c
        for c in candidates
    }
    selected_labels = st.multiselect(
        "Choose 2–4 candidates to compare",
        options=list(cand_options.keys()),
        max_selections=4,
        label_visibility="collapsed",
        placeholder="Select candidates…",
    )
    selected_candidates = [cand_options[l] for l in selected_labels]

with jd_col:
    jd_map  = {"— No JD (use existing scores) —": None}
    for jd in jds:
        jd_map[jd.get("title","Untitled")] = jd
    sel_jd_lbl = st.selectbox("JD for scoring", list(jd_map.keys()),
                               label_visibility="collapsed")
    sel_jd     = jd_map[sel_jd_lbl]

rescore_btn = st.button(
    "🎯 Score & Compare",
    type="primary",
    disabled=len(selected_candidates) < 2,
)

# ── Score if needed ────────────────────────────────────────────────────────────
if rescore_btn and len(selected_candidates) >= 2:
    scored_cands = []
    skill_matrix = sel_jd.get("skill_matrix") if sel_jd else None

    for c in selected_candidates:
        scored = dict(c)
        if skill_matrix and ai_key:
            with st.spinner(f"Scoring {c.get('full_name','?')}…"):
                snippet = (
                    f"Name: {c.get('full_name','')}\n"
                    f"Title: {c.get('current_title','')}\n"
                    f"Skills: {', '.join(c.get('skills') or [])}\n"
                    f"Summary: {(c.get('summary') or '')[:400]}"
                )
                result = score_candidate(ai_provider, ai_key, snippet, skill_matrix)
                if result:
                    scored["match_score"]    = result.get("match_score", c.get("match_score",0))
                    scored["ai_rationale"]   = result.get("rationale","")
                    scored["matched_skills"] = result.get("matched_skills",[])
                    scored["missing_skills"] = result.get("missing_skills",[])
        scored_cands.append(scored)

    st.session_state["compare_results"] = scored_cands

compare_results = st.session_state.get("compare_results", [])

if len(compare_results) >= 2:
    st.markdown("---")
    st.markdown("### Comparison")

    # ── Score bar chart ────────────────────────────────────────────────────────
    if HAS_PLOTLY:
        names  = [c.get("full_name","?")[:20] for c in compare_results]
        scores = [c.get("match_score",0) for c in compare_results]
        colors = ["#14B8A6","#F59E0B","#A5B4FC","#F0ABFC"][:len(compare_results)]

        fig = go.Figure(go.Bar(
            x=names, y=scores,
            marker_color=colors,
            text=[f"{s}%" for s in scores],
            textposition="outside",
        ))
        fig.update_layout(
            title=dict(text="Match Scores", font=dict(color="#F1F5F9", size=14)),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#94A3B8"),
            yaxis=dict(range=[0,105], gridcolor="#1E293B", tickformat="%d%%"),
            xaxis=dict(gridcolor="#1E293B"),
            height=300,
            margin=dict(t=40, b=20, l=20, r=20),
        )
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

    # ── Side-by-side cards ─────────────────────────────────────────────────────
    card_cols = st.columns(len(compare_results))
    col_colors = ["#14B8A6","#F59E0B","#A5B4FC","#F0ABFC"]

    for idx, (col, c) in enumerate(zip(card_cols, compare_results)):
        with col:
            score   = c.get("match_score", 0)
            sc_col  = col_colors[idx]
            stage   = c.get("stage","sourced")
            url     = c.get("profile_url","")
            matched = c.get("matched_skills",[])
            missing = c.get("missing_skills",[])
            skills  = c.get("skills",[])

            # Rank badge
            rank_labels = ["🥇","🥈","🥉","4️⃣"]
            sorted_scores = sorted([x.get("match_score",0) for x in compare_results], reverse=True)
            rank = sorted_scores.index(score) + 1 if score in sorted_scores else idx+1

            st.markdown(f"""
            <div style="background:#1E293B; border:2px solid {sc_col}40;
                        border-top:3px solid {sc_col}; border-radius:12px; padding:16px;">
                <div style="display:flex; justify-content:space-between; align-items:flex-start;">
                    <div style="font-size:1.4rem;">{rank_labels[idx]}</div>
                    <div style="font-size:1.6rem; font-weight:800; color:{sc_col};">{score}%</div>
                </div>
                <div style="font-weight:700; color:#F1F5F9; font-size:0.92rem; margin-top:8px;">
                    {c.get('full_name','Unknown')}
                </div>
                <div style="color:#64748B; font-size:0.78rem; margin-top:2px;">
                    {c.get('current_title','')[:40]}
                </div>
                <div style="color:#475569; font-size:0.72rem; margin-top:3px;">
                    {source_icon(c.get('source',''))} {c.get('source','')} &nbsp;·&nbsp;
                    <span style="color:{stage_color(stage)};">{stage.title()}</span>
                </div>
            </div>
            """, unsafe_allow_html=True)

            if url:
                st.link_button("🔗 Profile", url, use_container_width=True)

            # Skills comparison
            st.markdown("**Skills**")
            for s in skills[:6]:
                is_matched = s in matched
                color = "#86EFAC" if is_matched else "#94A3B8"
                icon  = "✅" if is_matched else "·"
                st.markdown(
                    f'<div style="font-size:0.78rem; color:{color}; margin:2px 0;">'
                    f'{icon} {s}</div>',
                    unsafe_allow_html=True,
                )

            # AI rationale
            if c.get("ai_rationale"):
                with st.expander("🧠 AI Notes", expanded=False):
                    st.markdown(c["ai_rationale"])

            if missing:
                with st.expander(f"⚠️ Missing ({len(missing)})", expanded=False):
                    for m in missing[:5]:
                        st.markdown(f"- {m}")

    # ── Verdict ────────────────────────────────────────────────────────────────
    if ai_key and all(c.get("ai_rationale") for c in compare_results):
        st.markdown("---")
        st.markdown("### 🏆 Ranking")

        ranked = sorted(compare_results, key=lambda x: x.get("match_score",0), reverse=True)
        for i, c in enumerate(ranked):
            medals = ["🥇","🥈","🥉","4️⃣"]
            sc = col_colors[i]
            st.markdown(f"""
            <div style="background:#1E293B; border-left:3px solid {sc};
                        border-radius:0 8px 8px 0; padding:10px 14px; margin-bottom:6px;
                        display:flex; align-items:center; gap:12px;">
                <span style="font-size:1.2rem;">{medals[i]}</span>
                <div>
                    <span style="font-weight:700; color:#F1F5F9;">{c.get('full_name','?')}</span>
                    <span style="color:#475569; font-size:0.8rem; margin-left:8px;">{c.get('match_score',0)}% match</span>
                </div>
            </div>
            """, unsafe_allow_html=True)

elif len(selected_candidates) >= 2:
    st.info("Click **Score & Compare** to run the comparison.")
elif selected_candidates:
    st.info("Select at least 2 candidates to compare.")
