import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st
from core.auth import require_auth, load_user_session, get_ai_key, get_ai_provider
from core.cv_parser import parse_cv_text, extract_text_from_pdf, score_cv_against_matrix
from core.database import save_candidate_with_dedup, get_jd_library, get_searches
from components.sidebar import render_sidebar
from utils.helpers import inject_global_css, empty_state, format_skills_pills

st.set_page_config(
    page_title="CV Upload — The Sourcer",
    page_icon="📄",
    layout="wide",
)
inject_global_css()
require_auth()

user = st.session_state.user
load_user_session(user.id)
render_sidebar()

st.markdown("""
<div style="padding:1.25rem 0 0.75rem;">
    <div style="font-size:1.5rem; font-weight:800; color:#F1F5F9;">📄 CV Upload & AI Parse</div>
    <div style="color:#64748B; font-size:0.85rem; margin-top:3px;">
        Upload a PDF or paste CV text — AI extracts the candidate profile and adds them to your database.
    </div>
</div>
""", unsafe_allow_html=True)

ai_key      = get_ai_key()
ai_provider = get_ai_provider()

if not ai_key:
    st.error("🔑 Add an AI API key in Settings (Groq is free!) to use CV parsing.")
    if st.button("⚙️ Go to Settings", type="primary"):
        st.switch_page("pages/09_Settings.py")
    st.stop()

# ── Init session state ─────────────────────────────────────────────────────────
for k, v in [
    ("cv_parsed", None), ("cv_text", ""), ("cv_scored", None),
]:
    if k not in st.session_state:
        st.session_state[k] = v

# ── Layout ─────────────────────────────────────────────────────────────────────
left, right = st.columns([1, 1], gap="large")

with left:
    st.markdown("### 1 · Upload or Paste CV")

    upload_tab, paste_tab = st.tabs(["📎 Upload PDF", "📝 Paste Text"])

    with upload_tab:
        uploaded = st.file_uploader(
            "Upload CV / Resume",
            type=["pdf"],
            help="PDF format only. Max 10MB.",
            label_visibility="collapsed",
        )
        if uploaded:
            with st.spinner("📄 Extracting text from PDF…"):
                cv_text = extract_text_from_pdf(uploaded)
            if cv_text.strip():
                st.session_state.cv_text = cv_text
                st.success(f"✅ Extracted {len(cv_text):,} characters from PDF.")
            else:
                st.error("Could not extract text from this PDF. Try copy-pasting the text instead.")

    with paste_tab:
        pasted = st.text_area(
            "Paste CV text here",
            value=st.session_state.cv_text if not uploaded else "",
            placeholder="Paste the full CV or resume text here…",
            height=280,
            label_visibility="collapsed",
        )
        if pasted.strip():
            st.session_state.cv_text = pasted

    cv_text = st.session_state.cv_text

    if cv_text:
        st.markdown(
            f'<div style="color:#475569; font-size:0.75rem; margin-top:4px;">'
            f'{len(cv_text):,} characters ready</div>',
            unsafe_allow_html=True,
        )

    st.markdown("---")
    st.markdown("### 2 · Score Against JD (Optional)")
    st.markdown('<div style="color:#64748B; font-size:0.82rem; margin-bottom:8px;">Select a saved JD to score this candidate against your skill matrix.</div>', unsafe_allow_html=True)

    jds = get_jd_library(user.id)
    jd_options = {"— Skip scoring —": None}
    for jd in jds:
        jd_options[jd.get("title", "Untitled")] = jd

    selected_jd_label = st.selectbox("Select JD", list(jd_options.keys()),
                                      label_visibility="collapsed")
    selected_jd = jd_options[selected_jd_label]

    search_options = {"— No search —": None}
    for s in get_searches(user.id)[:10]:
        search_options[s.get("name","Unnamed")] = s.get("id")
    sel_search_lbl = st.selectbox("Link to search", list(search_options.keys()),
                                   label_visibility="collapsed")
    sel_search_id  = search_options[sel_search_lbl]

    parse_btn = st.button(
        "🤖 Parse CV with AI",
        type="primary",
        use_container_width=True,
        disabled=not cv_text.strip(),
    )

with right:
    st.markdown("### 3 · Parsed Candidate Profile")

    if parse_btn and cv_text.strip():
        with st.spinner("🧠 AI is reading the CV…"):
            parsed = parse_cv_text(ai_provider, ai_key, cv_text)

        if parsed:
            # Score if JD selected
            if selected_jd and selected_jd.get("skill_matrix"):
                with st.spinner("🎯 Scoring against JD…"):
                    score_result = score_cv_against_matrix(
                        ai_provider, ai_key, parsed, selected_jd["skill_matrix"]
                    )
                parsed["match_score"]   = score_result.get("match_score", 0)
                parsed["ai_rationale"]  = score_result.get("rationale", "")
                parsed["matched_skills"] = score_result.get("matched_skills", [])
                parsed["missing_skills"] = score_result.get("missing_skills", [])
                st.session_state.cv_scored = score_result

            st.session_state.cv_parsed = parsed
            st.success("✅ CV parsed successfully!")
        else:
            st.error("Could not parse this CV. Try pasting the text manually.")

    parsed = st.session_state.cv_parsed

    if parsed:
        score   = parsed.get("match_score", 0)
        sc_col  = "#10B981" if score >= 80 else "#14B8A6" if score >= 65 else "#F59E0B" if score >= 45 else "#94A3B8"
        rd      = parsed.get("raw_data") or {}

        # Profile card
        st.markdown(f"""
        <div style="background:#1E293B; border:1px solid #334155; border-radius:12px;
                    padding:20px; margin-bottom:1rem;">
            <div style="display:flex; justify-content:space-between; align-items:flex-start;">
                <div style="flex:1;">
                    <div style="font-size:1.1rem; font-weight:800; color:#F1F5F9;">
                        {parsed.get('full_name') or '—'}
                    </div>
                    <div style="color:#94A3B8; font-size:0.85rem; margin-top:3px;">
                        {parsed.get('current_title') or '—'}
                    </div>
                    <div style="color:#64748B; font-size:0.78rem; margin-top:4px;">
                        {'📍 ' + parsed.get('location','') + '  ' if parsed.get('location') else ''}
                        {'✉️ ' + parsed.get('email','') if parsed.get('email') else ''}
                    </div>
                    <div style="margin-top:10px;">
                        {format_skills_pills(parsed.get('skills',[]), max_show=10)}
                    </div>
                </div>
                <div style="text-align:right; flex-shrink:0; margin-left:16px;">
                    <div style="font-size:2rem; font-weight:800; color:{sc_col};">{score}%</div>
                    <div style="font-size:10px; color:#475569;">match score</div>
                    <div style="font-size:0.78rem; color:#64748B; margin-top:4px;">
                        {parsed.get('experience_years','?')} yrs exp
                    </div>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        # Summary
        if parsed.get("summary"):
            st.markdown(f"""
            <div style="background:#0F172A; border-radius:8px; padding:12px 14px;
                        font-size:0.83rem; color:#94A3B8; line-height:1.6; margin-bottom:1rem;">
                {parsed['summary']}
            </div>
            """, unsafe_allow_html=True)

        # AI scoring detail
        scored = st.session_state.cv_scored
        if scored:
            sc1, sc2 = st.columns(2)
            with sc1:
                if scored.get("matched_skills"):
                    st.markdown("**✅ Matched Skills**")
                    for s in scored["matched_skills"][:6]:
                        st.markdown(f"- {s}")
            with sc2:
                if scored.get("missing_skills"):
                    st.markdown("**⚠️ Missing Skills**")
                    for s in scored["missing_skills"][:6]:
                        st.markdown(f"- {s}")
            if scored.get("rationale"):
                st.info(scored["rationale"])

        # Work history
        wh = rd.get("work_history", [])
        if wh:
            with st.expander("💼 Work History", expanded=False):
                for job in wh[:4]:
                    st.markdown(f"**{job.get('title','')}** at {job.get('company','')} · {job.get('duration','')}")
                    for h in (job.get("highlights") or [])[:2]:
                        st.markdown(f"  - {h}")

        # Education
        edu = rd.get("education", [])
        if edu:
            with st.expander("🎓 Education", expanded=False):
                for e in edu:
                    st.markdown(f"**{e.get('degree','')}** — {e.get('institution','')} {e.get('year','')}")

        # Certs
        certs = rd.get("certifications", [])
        if certs:
            with st.expander("📜 Certifications", expanded=False):
                for cert in certs:
                    st.markdown(f"- {cert}")

        st.markdown("---")

        # ── Save to database ───────────────────────────────────────────────────
        st.markdown("### 4 · Save to Database")
        c1, c2 = st.columns(2)
        with c1:
            override_name = st.text_input(
                "Override name (optional)", value=parsed.get("full_name",""),
                placeholder="Confirm or correct the name"
            )
        with c2:
            override_title = st.text_input(
                "Override title (optional)", value=parsed.get("current_title",""),
                placeholder="Confirm or correct the title"
            )

        if st.button("💾 Save Candidate to Database", type="primary", use_container_width=True):
            candidate_to_save = {**parsed}
            if override_name.strip():
                candidate_to_save["full_name"] = override_name.strip()
            if override_title.strip():
                candidate_to_save["current_title"] = override_title.strip()

            result = save_candidate_with_dedup(
                user.id, candidate_to_save, search_id=sel_search_id
            )

            if result["status"] == "saved":
                st.success(f"✅ {candidate_to_save.get('full_name','Candidate')} saved to your database!")
                # Clear form
                st.session_state.cv_parsed = None
                st.session_state.cv_text   = ""
                st.session_state.cv_scored = None
                st.rerun()
            elif result["status"] == "duplicate":
                ex = result["existing"]
                st.warning(
                    f"⚠️ This candidate already exists in your database as "
                    f"**{ex.get('full_name','Unknown')}** (stage: {ex.get('stage','sourced').title()})."
                )
                if st.button("Save Anyway (create duplicate)", key="force_save"):
                    save_candidate_with_dedup(user.id, candidate_to_save,
                                               search_id=sel_search_id, force=True)
                    st.success("Saved!")
                    st.rerun()
            else:
                st.error("Save failed — please try again.")

        if st.button("🗑 Clear & Parse Another", use_container_width=True):
            st.session_state.cv_parsed = None
            st.session_state.cv_text   = ""
            st.session_state.cv_scored = None
            st.rerun()

    else:
        # Empty state
        st.markdown("""
        <div style="background:#1E293B; border:2px dashed #1E293B; border-radius:14px;
                    padding:4rem 2rem; text-align:center; margin-top:1rem;">
            <div style="font-size:2.5rem; margin-bottom:1rem;">📄</div>
            <div style="font-weight:600; color:#F1F5F9; margin-bottom:6px;">
                Parsed profile will appear here
            </div>
            <div style="color:#334155; font-size:0.83rem; line-height:1.6;">
                Upload a PDF or paste text on the left,<br>
                then click Parse CV with AI
            </div>
        </div>
        """, unsafe_allow_html=True)
