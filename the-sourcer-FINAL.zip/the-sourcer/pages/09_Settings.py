import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

__doc__ = None  # prevent Streamlit rendering module docstring
"""
pages/09_Settings.py — Settings, API Keys, Profile, Team
Multi-provider AI support: Anthropic, OpenAI, Groq (free), Mistral (free)
"""
import streamlit as st
from core.auth import require_auth, load_user_session, get_ai_provider
from core.database import (
    save_api_keys, get_api_keys, update_profile,
    get_profile, create_team, get_team,
)
from core.ai_engine import PROVIDER_INFO
from components.sidebar import render_sidebar
from utils.helpers import inject_global_css

st.set_page_config(
    page_title="Settings — The Sourcer",
    page_icon="⚙️",
    layout="wide",
)
inject_global_css()
require_auth()

user = st.session_state.user
load_user_session(user.id)
render_sidebar()

st.markdown("""
<div style="padding:1.25rem 0 0.75rem;">
    <div style="font-size:1.5rem; font-weight:800; color:#F1F5F9;">⚙️ Settings</div>
    <div style="color:#64748B; font-size:0.85rem; margin-top:3px;">
        API keys, profile, and team workspace.
    </div>
</div>
""", unsafe_allow_html=True)

profile  = st.session_state.get("profile") or {}
api_keys = get_api_keys(user.id) or {}

tab_api, tab_search, tab_profile, tab_team = st.tabs([
    "🤖 AI Keys", "🔍 Search Keys", "👤 Profile", "🤝 Team"
])

# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — AI PROVIDER KEYS
# ══════════════════════════════════════════════════════════════════════════════
with tab_api:

    # ── Free tier info banner ──────────────────────────────────────────────────
    st.markdown("""
    <div style="background:linear-gradient(135deg,#0F2A1E,#1E293B); border:1px solid #166534;
                border-radius:12px; padding:16px 20px; margin-bottom:1.5rem;">
        <div style="font-weight:700; color:#86EFAC; margin-bottom:6px;">💡 Free Options Available</div>
        <div style="color:#64748B; font-size:0.82rem; line-height:1.7;">
            You don't need to pay to use The Sourcer's AI features.<br>
            <b style="color:#86EFAC;">Groq</b> offers a generous free tier (14,400 requests/day) —
            perfect for getting started.<br>
            <b style="color:#86EFAC;">Mistral</b> also offers free access to open models
            (1 billion tokens/month).<br>
            Add whichever key(s) you have and select your preferred provider below.
        </div>
    </div>
    """, unsafe_allow_html=True)

    # ── Provider cards ─────────────────────────────────────────────────────────
    st.markdown("### Choose Your AI Provider")
    st.markdown('<div style="color:#64748B; font-size:0.82rem; margin-bottom:1rem;">Select the provider you want to use for JD analysis, scoring, and outreach generation. You can add multiple keys and switch anytime.</div>', unsafe_allow_html=True)

    current_provider = api_keys.get("ai_provider") or "anthropic"
    p_cols = st.columns(4)
    provider_order = ["anthropic", "openai", "groq", "mistral"]

    for i, pid in enumerate(provider_order):
        info = PROVIDER_INFO[pid]
        is_active = current_provider == pid
        border_col = "#14B8A6" if is_active else "#1E293B"
        bg_col     = "#0D2726" if is_active else "#1E293B"

        with p_cols[i]:
            st.markdown(f"""
            <div style="background:{bg_col}; border:2px solid {border_col};
                        border-radius:12px; padding:14px; text-align:center; margin-bottom:8px;">
                <div style="font-size:1.6rem;">{info['icon']}</div>
                <div style="font-weight:700; color:#F1F5F9; font-size:0.88rem; margin-top:4px;">
                    {info['name']}
                </div>
                <div style="margin-top:6px;">
                    {'<span style="background:#166534; color:#86EFAC; border-radius:999px; padding:2px 8px; font-size:10px; font-weight:700;">FREE TIER</span>' if info['free'] else '<span style="background:#1E293B; color:#64748B; border-radius:999px; padding:2px 8px; font-size:10px;">PAID</span>'}
                </div>
                <div style="color:#475569; font-size:0.72rem; margin-top:8px; line-height:1.5;">
                    {info['note']}
                </div>
                {'<div style="color:#14B8A6; font-size:10px; font-weight:700; margin-top:8px;">✓ ACTIVE</div>' if is_active else ''}
            </div>
            """, unsafe_allow_html=True)
            if not is_active:
                if st.button(f"Use {info['name'].split()[0]}", key=f"sel_{pid}",
                             use_container_width=True):
                    save_api_keys(user.id, {"ai_provider": pid})
                    st.session_state.api_keys = get_api_keys(user.id)
                    st.rerun()

    st.markdown("---")

    # ── Key input form ─────────────────────────────────────────────────────────
    st.markdown("### Add Your API Keys")
    st.markdown('<div style="color:#64748B; font-size:0.82rem; margin-bottom:1rem;">Keys are stored securely in your account. Add as many as you like and switch providers freely.</div>', unsafe_allow_html=True)

    with st.form("ai_keys_form"):
        c1, c2 = st.columns(2)

        with c1:
            st.markdown("#### 🤖 Anthropic Claude")
            st.markdown('<div style="color:#475569; font-size:0.75rem; margin-bottom:6px;">Best analysis quality. Get key: <a href="https://console.anthropic.com" target="_blank" style="color:#14B8A6;">console.anthropic.com</a></div>', unsafe_allow_html=True)
            ant_key = st.text_input(
                "Anthropic API Key",
                value=api_keys.get("anthropic_key","") or "",
                type="password",
                placeholder="sk-ant-…",
            )

            st.markdown("#### 🟢 OpenAI")
            st.markdown('<div style="color:#475569; font-size:0.75rem; margin-bottom:6px;">GPT-4o / GPT-4o-mini. Get key: <a href="https://platform.openai.com/api-keys" target="_blank" style="color:#14B8A6;">platform.openai.com</a></div>', unsafe_allow_html=True)
            oai_key = st.text_input(
                "OpenAI API Key",
                value=api_keys.get("openai_key","") or "",
                type="password",
                placeholder="sk-…",
            )

        with c2:
            st.markdown("#### ⚡ Groq (Free Tier Available)")
            st.markdown('<div style="color:#475569; font-size:0.75rem; margin-bottom:6px;">14,400 free requests/day. Get key: <a href="https://console.groq.com/keys" target="_blank" style="color:#14B8A6;">console.groq.com</a></div>', unsafe_allow_html=True)
            groq_key = st.text_input(
                "Groq API Key",
                value=api_keys.get("groq_key","") or "",
                type="password",
                placeholder="gsk_…",
            )

            st.markdown("#### 🌊 Mistral AI (Free Tier Available)")
            st.markdown('<div style="color:#475569; font-size:0.75rem; margin-bottom:6px;">1B free tokens/month (open models). Get key: <a href="https://console.mistral.ai/api-keys" target="_blank" style="color:#14B8A6;">console.mistral.ai</a></div>', unsafe_allow_html=True)
            mist_key = st.text_input(
                "Mistral API Key",
                value=api_keys.get("mistral_key","") or "",
                type="password",
                placeholder="…",
            )

        saved_ai = st.form_submit_button("💾 Save AI Keys", type="primary", use_container_width=True)

    if saved_ai:
        ok = save_api_keys(user.id, {
            "anthropic_key": ant_key.strip()  or None,
            "openai_key":    oai_key.strip()  or None,
            "groq_key":      groq_key.strip() or None,
            "mistral_key":   mist_key.strip() or None,
        })
        if ok:
            st.session_state.api_keys = get_api_keys(user.id)
            st.success("✅ AI keys saved!")
        else:
            st.error("Failed to save — please try again.")

    # ── Key status ─────────────────────────────────────────────────────────────
    st.markdown("---")
    st.markdown("#### Key Status")
    fresh = st.session_state.get("api_keys") or {}
    ks1, ks2, ks3, ks4 = st.columns(4)
    for col, pid, col_name in [
        (ks1, "anthropic", "anthropic_key"),
        (ks2, "openai",    "openai_key"),
        (ks3, "groq",      "groq_key"),
        (ks4, "mistral",   "mistral_key"),
    ]:
        info = PROVIDER_INFO[pid]
        has  = bool(fresh.get(col_name))
        active = (fresh.get("ai_provider") or "anthropic") == pid
        with col:
            st.markdown(f"""
            <div style="background:#1E293B; border:1px solid {'#14B8A6' if active else '#334155'};
                        border-radius:10px; padding:12px; text-align:center;">
                <div style="font-size:1.2rem;">{info['icon']}</div>
                <div style="font-size:0.78rem; font-weight:600; color:#F1F5F9; margin-top:4px;">{info['name'].split()[0]}</div>
                <div style="font-size:0.7rem; margin-top:4px; color:{'#10B981' if has else '#F87171'};">
                    {'✅ Connected' if has else '❌ Not set'}
                </div>
                {'<div style="font-size:9px; color:#14B8A6; font-weight:700; margin-top:3px;">ACTIVE</div>' if active else ''}
            </div>
            """, unsafe_allow_html=True)

    # ── Free tier summary ──────────────────────────────────────────────────────
    st.markdown("---")
    st.markdown("#### 📊 Free Tier Limits at a Glance")
    st.markdown("""
| Provider | Free Tier | Requests/Day | Best For |
|---|---|---|---|
| **Groq** ⚡ | ✅ Yes | ~14,400 req/day | JD analysis, scoring, outreach |
| **Mistral** 🌊 | ✅ Yes (open models) | ~1B tokens/month | All AI features |
| **OpenAI** 🟢 | ❌ Paid only | Paid | Highest accuracy |
| **Anthropic** 🤖 | ❌ Paid only | Paid | Best analysis quality |

**How many requests does a typical search use?**
- 1 JD analysis = **3 AI calls** (Prompts 1, 2, 3)
- 1 candidate scoring = **1 AI call** per candidate
- 1 outreach message = **1 AI call**
- Typical full search (20 candidates) = **~25 AI calls total**

**Groq free tier = ~576 full searches/day.** More than enough for most recruiters.
    """)

    # ── API Key Tester ─────────────────────────────────────────────────────────
    st.markdown("---")
    st.markdown("#### 🧪 Test Your AI Key")
    st.markdown('<div style="color:#64748B;font-size:.82rem;margin-bottom:.75rem;">Send a quick test call to verify your key works before running a search.</div>', unsafe_allow_html=True)

    test_col1, test_col2 = st.columns([3, 1])
    with test_col1:
        test_provider = st.selectbox(
            "Provider to test",
            list(PROVIDER_INFO.keys()),
            format_func=lambda x: f"{PROVIDER_INFO[x]['icon']} {PROVIDER_INFO[x]['name']}",
            label_visibility="collapsed",
        )
    with test_col2:
        test_btn = st.button("🧪 Test Key", use_container_width=True, type="primary")

    if test_btn:
        from core.auth import get_ai_key, get_ai_provider
        # Temporarily override provider for test
        fresh_keys = st.session_state.get("api_keys") or {}
        key_map = {"anthropic": "anthropic_key", "openai": "openai_key",
                   "groq": "groq_key", "mistral": "mistral_key"}
        test_key = fresh_keys.get(key_map.get(test_provider, "anthropic_key"), "")
        if not test_key:
            st.error(f"No {PROVIDER_INFO[test_provider]['name']} key saved. Add it above first.")
        else:
            with st.spinner(f"Testing {PROVIDER_INFO[test_provider]['name']} key…"):
                from core.ai_engine import _call_ai
                result = _call_ai(
                    provider=test_provider,
                    api_key=test_key,
                    system_prompt="You are a helpful assistant. Reply with exactly: OK",
                    user_content="Reply with exactly: OK",
                    max_tokens=10,
                )
            if result and "ok" in result.lower():
                st.success(f"✅ {PROVIDER_INFO[test_provider]['name']} key works perfectly!")
            elif result:
                st.success(f"✅ Key works! Response: {result[:50]}")
            else:
                st.error(f"❌ Key test failed. Check the key and try again.")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — SEARCH / SOURCING KEYS
# ══════════════════════════════════════════════════════════════════════════════
with tab_search:

    st.markdown("""
    <div style="background:linear-gradient(135deg,#1A1A2E,#1E293B); border:1px solid #334155;
                border-radius:12px; padding:16px 20px; margin-bottom:1.5rem;">
        <div style="font-weight:700; color:#F1F5F9; margin-bottom:6px;">🔍 Search API Keys</div>
        <div style="color:#64748B; font-size:0.82rem; line-height:1.7;">
            These power candidate sourcing across LinkedIn X-Ray, GitHub, Stack Overflow, and job boards.<br>
            <b style="color:#14B8A6;">Google Custom Search</b> (100 free searches/day) or
            <b style="color:#14B8A6;">SerpAPI</b> (100 free searches/month) for X-Ray sourcing.<br>
            <b style="color:#14B8A6;">GitHub Token</b> is optional — increases rate limits for developer search.
        </div>
    </div>
    """, unsafe_allow_html=True)

    with st.form("search_keys_form"):
        st.markdown("#### 🌐 SerpAPI (Recommended)")
        st.markdown('<div style="color:#475569; font-size:0.78rem; margin-bottom:10px;">Powers LinkedIn X-Ray + job board searches. <b>Free: 100 queries/day</b>.</div>', unsafe_allow_html=True)
        sg1, sg2 = st.columns(2)
        with sg1:
            g_api = st.text_input(
                "Google API Key",
                value=api_keys.get("google_api_key","") or "",
                type="password",
                placeholder="AIza…",
                help="console.cloud.google.com → Credentials → Create API Key",
            )
        with sg2:
            g_cse = st.text_input(
                "Custom Search Engine ID (cx)",
                value=api_keys.get("google_cse_id","") or "",
                type="password",
                placeholder="a1b2c3…",
                help="programmablesearchengine.google.com → Create → Search Engine ID",
            )

        st.markdown("---")
        st.markdown("#### 🌐 SerpAPI (Alternative to Google CSE)")
        st.markdown('<div style="color:#475569; font-size:0.78rem; margin-bottom:10px;"><b style="color:#86EFAC;">Recommended primary search API.</b> Free: 100 searches/month. Simpler setup than Google CSE. Used for LinkedIn X-Ray + all job board searches. Get key at <a href="https://serpapi.com" target="_blank" style="color:#14B8A6;">serpapi.com</a></div>', unsafe_allow_html=True)
        serp_key = st.text_input(
            "SerpAPI Key",
            value=api_keys.get("serp_api_key","") or "",
            type="password",
            placeholder="…",
        )

        st.markdown("---")
        st.markdown("#### 🐙 GitHub Token (Optional)")
        st.markdown('<div style="color:#475569; font-size:0.78rem; margin-bottom:10px;">Without token: 10 req/min. With token: 30 req/min and better results. Free — just needs a GitHub account.</div>', unsafe_allow_html=True)
        gh_tok = st.text_input(
            "GitHub Personal Access Token",
            value=api_keys.get("github_token","") or "",
            type="password",
            placeholder="ghp_…",
            help="github.com → Settings → Developer settings → Personal access tokens (classic) → Scopes: read:user",
        )

        saved_src = st.form_submit_button("💾 Save Search Keys", type="primary", use_container_width=True)

    if saved_src:
        ok = save_api_keys(user.id, {
            "google_api_key": g_api.strip()    or None,
            "google_cse_id":  g_cse.strip()    or None,
            "serp_api_key":   serp_key.strip() or None,
            "github_token":   gh_tok.strip()   or None,
        })
        if ok:
            st.session_state.api_keys = get_api_keys(user.id)
            st.success("✅ Search keys saved!")
        else:
            st.error("Failed to save.")

    # ── Search key status ──────────────────────────────────────────────────────
    st.markdown("---")
    fresh = st.session_state.get("api_keys") or {}
    sk1, sk2, sk3 = st.columns(3)
    search_keys_status = [
        ("🔍 Google CSE",  bool(fresh.get("google_api_key") and fresh.get("google_cse_id")),
         "100 searches/day free"),
        ("🌐 SerpAPI",     bool(fresh.get("serp_api_key")),   "100 searches/month free"),
        ("🐙 GitHub",      bool(fresh.get("github_token")),   "Optional — increases limits"),
    ]
    for col, (label, has, note) in zip([sk1, sk2, sk3], search_keys_status):
        with col:
            st.markdown(f"""
            <div style="background:#1E293B; border:1px solid {'#14B8A6' if has else '#334155'};
                        border-radius:10px; padding:14px; text-align:center;">
                <div style="font-size:0.88rem; font-weight:600; color:#F1F5F9;">{label}</div>
                <div style="font-size:0.7rem; margin-top:6px; color:{'#10B981' if has else '#F87171'};">
                    {'✅ Connected' if has else '❌ Not set'}
                </div>
                <div style="font-size:0.68rem; color:#334155; margin-top:4px;">{note}</div>
            </div>
            """, unsafe_allow_html=True)

    # ── Setup guides ───────────────────────────────────────────────────────────
    with st.expander("📖 How to set up Google Custom Search (step-by-step)", expanded=False):
        st.markdown("""
**Step 1 — Get a Google API Key**
1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Create a new project (or pick an existing one)
3. In the left menu: **APIs & Services → Credentials**
4. Click **Create Credentials → API Key**
5. Copy the key

**Step 2 — Enable the Custom Search API**
1. Still in Cloud Console: **APIs & Services → Library**
2. Search for **"Custom Search API"**
3. Click it → click **Enable**

**Step 3 — Create a Search Engine**
1. Go to [programmablesearchengine.google.com](https://programmablesearchengine.google.com)
2. Click **Add** → Name it anything (e.g. "The Sourcer")
3. Under "What to search": choose **"Search the entire web"**
4. Click **Create**
5. On the next screen, copy the **Search Engine ID** (the `cx` value)

**Free limit:** 100 queries/day. To increase: enable billing in Google Cloud (first 1,000 paid queries are ~$5).
        """)

    with st.expander("📖 How to set up SerpAPI", expanded=False):
        st.markdown("""
1. Go to [serpapi.com](https://serpapi.com) and create a free account
2. Go to **Dashboard → API Key**
3. Copy your key and paste it above

**Free tier:** 100 searches/month. Paid plans start at $50/month for 5,000 searches.
SerpAPI is a simpler alternative if you have trouble setting up Google CSE.
        """)

    with st.expander("📖 How to get a GitHub Token", expanded=False):
        st.markdown("""
1. Go to [github.com](https://github.com) and sign in
2. Click your profile picture → **Settings**
3. Scroll down → **Developer settings**
4. Click **Personal access tokens → Tokens (classic)**
5. Click **Generate new token (classic)**
6. Give it any name (e.g. "The Sourcer")
7. Select scopes: **`read:user`** and **`user:email`**
8. Click **Generate token**
9. Copy and paste it above (you only see it once!)
        """)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — PROFILE
# ══════════════════════════════════════════════════════════════════════════════
with tab_profile:
    with st.form("profile_form"):
        st.markdown("#### 👤 Your Profile")
        pc1, pc2 = st.columns(2)
        with pc1:
            fn  = st.text_input("Full Name",    value=profile.get("full_name","") or "")
            co  = st.text_input("Company",       value=profile.get("company","")   or "")
        with pc2:
            jt  = st.text_input("Your Job Title", value=profile.get("job_title","") or "",
                                 placeholder="e.g. Talent Partner, Senior Recruiter")
            em  = st.text_input("Email", value=profile.get("email","") or user.email or "",
                                 disabled=True)
        save_p = st.form_submit_button("💾 Save Profile", type="primary")

    if save_p:
        ok = update_profile(user.id, {
            "full_name": fn.strip(),
            "company":   co.strip(),
            "job_title": jt.strip(),
        })
        if ok:
            st.session_state.profile = get_profile(user.id)
            st.success("✅ Profile updated!")
        else:
            st.error("Update failed.")

    st.markdown("---")
    created = (profile.get("created_at") or "")[:10]
    role    = profile.get("role","user")
    st.markdown(f"""
    <div style="background:#1E293B; border:1px solid #334155; border-radius:10px; padding:16px 20px;">
        <div style="display:flex; gap:40px; flex-wrap:wrap;">
            <div>
                <div style="font-size:0.68rem; color:#334155; text-transform:uppercase; letter-spacing:0.08em;">Account Role</div>
                <div style="font-weight:600; color:#F1F5F9; margin-top:4px; text-transform:capitalize;">{role}</div>
            </div>
            <div>
                <div style="font-size:0.68rem; color:#334155; text-transform:uppercase; letter-spacing:0.08em;">Member Since</div>
                <div style="font-weight:600; color:#F1F5F9; margin-top:4px;">{created}</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 — TEAM
# ══════════════════════════════════════════════════════════════════════════════
with tab_team:
    st.markdown("#### 🤝 Team Workspace")
    st.markdown('<div style="color:#64748B; font-size:0.85rem; margin-bottom:1rem;">Share candidates and collaborate with colleagues. Team members can see shared candidates in the database.</div>', unsafe_allow_html=True)

    team_id = profile.get("team_id")

    if team_id:
        team = get_team(team_id)
        if team:
            members = team.get("team_members") or []
            st.markdown(f"""
            <div style="background:#1E293B; border:1px solid #0D9488; border-radius:10px;
                        padding:16px 20px; margin-bottom:1rem;">
                <div style="font-weight:700; color:#F1F5F9; font-size:1rem;">🏢 {team.get('name','Team')}</div>
                <div style="color:#64748B; font-size:0.8rem; margin-top:4px;">{len(members)} member(s)</div>
            </div>
            """, unsafe_allow_html=True)
            for m in members:
                p     = m.get("profiles") or {}
                mname = p.get("full_name","Unknown") if isinstance(p, dict) else "Unknown"
                memail = p.get("email","") if isinstance(p, dict) else ""
                mrole = m.get("role","member")
                st.markdown(f"- **{mname}** (`{memail}`) — `{mrole}`")
        else:
            st.warning("Team not found.")
    else:
        st.info("You are not part of a team yet. Create one to start collaborating.")
        with st.form("create_team_form"):
            tname = st.text_input("Team Name", placeholder="e.g. Talent Acquisition · EMEA")
            crt   = st.form_submit_button("🤝 Create Team", type="primary")
        if crt and tname.strip():
            tid = create_team(tname.strip(), user.id)
            if tid:
                st.success(f"✅ Team '{tname}' created!")
                st.session_state.profile = get_profile(user.id)
                st.rerun()
