__doc__ = None
# components/onboarding.py — First-time user onboarding
# Uses native Streamlit only — no HTML overlay (broken on mobile)
import streamlit as st
from core.database import mark_onboarding_complete, complete_onboarding_step

STEPS = [
    {
        "id":    "welcome",
        "icon":  "👋",
        "title": "Welcome to The Sourcer",
        "body":  "Your AI-powered talent intelligence platform. Find the best candidates across LinkedIn, GitHub, Stack Overflow, and 15+ job boards worldwide — all in one place.",
    },
    {
        "id":    "api_keys",
        "icon":  "🔑",
        "title": "Add Your API Keys",
        "body":  "**AI Analysis — pick one (free options available):**\n• ⚡ Groq — FREE 14,400 req/day → console.groq.com\n• 🌊 Mistral — FREE open models → console.mistral.ai\n• 🤖 Anthropic / 🟢 OpenAI — paid options\n\n**Sourcing — pick one:**\n• 🌐 SerpAPI — 100 free searches/month → serpapi.com\n• 🔍 Google Custom Search — 100 free/day\n\nAdd keys in **Settings → AI Keys** and **Settings → Search Keys**.",
    },
    {
        "id":    "search",
        "icon":  "🔍",
        "title": "Start With a Job Description",
        "body":  "Paste any job description and click **Analyse JD & Build Search**. The AI will understand hiring intent, build a weighted skill matrix, generate Boolean strings, and auto-fill all search filters.\n\nOr use a **Search Template** to skip the JD step entirely.",
    },
    {
        "id":    "sources",
        "icon":  "🌐",
        "title": "Search Everywhere at Once",
        "body":  "One click searches:\n• 🔵 LinkedIn profiles via X-Ray\n• 🐙 GitHub developer profiles\n• 📚 Stack Overflow experts\n• 📋 Regional job boards (Naukri, Reed, InfoJobs, Bayt…)\n• 📄 CVs published on the open web\n\nAll results are deduplicated and AI-scored.",
    },
    {
        "id":    "pipeline",
        "icon":  "🚀",
        "title": "You're Ready!",
        "body":  "Save candidates, move them through your pipeline (Sourced → Reviewed → Contacted → Responded → Interview), draft personalised outreach, and use Bulk Outreach for multiple candidates at once.\n\nCheck Analytics to see which sources deliver the best matches.",
    },
]


def render_onboarding() -> bool:
    """
    Render onboarding if not completed.
    Returns True if active (caller should st.stop()).
    Pure Streamlit — no HTML overlay.
    """
    user = st.session_state.get("user")
    if not user:
        return False
    profile = st.session_state.get("profile") or {}
    if profile.get("onboarding_completed"):
        return False
    if "onboarding_step" not in st.session_state:
        st.session_state.onboarding_step = 0
    step_idx = st.session_state.onboarding_step
    total    = len(STEPS)
    if step_idx >= total:
        return False

    step = STEPS[step_idx]

    # Hide sidebar for clean full-page onboarding
    st.markdown("""
<style>
[data-testid="stSidebar"]        { display:none !important; }
[data-testid="collapsedControl"] { display:none !important; }
#MainMenu { visibility:hidden !important; }
header    { visibility:hidden !important; }
footer    { visibility:hidden !important; }
.block-container { max-width:580px !important; margin:0 auto !important; padding-top:4rem !important; }
</style>""", unsafe_allow_html=True)

    # Progress dots
    dots = "".join(
        f'<span style="display:inline-block;width:10px;height:10px;border-radius:50%;'
        f'background:{"#0D9488" if i == step_idx else "#334155"};margin:0 4px;"></span>'
        for i in range(total)
    )

    # Card
    st.markdown(f"""
<div style="background:#1E293B;border:1px solid #334155;border-radius:20px;
            padding:2.5rem 2rem 2rem;margin-bottom:1.5rem;">
    <div style="text-align:center;margin-bottom:1.5rem;">
        <div style="font-size:3rem;margin-bottom:.75rem;">{step["icon"]}</div>
        <div style="font-size:1.35rem;font-weight:800;color:#F1F5F9;">{step["title"]}</div>
        <div style="margin-top:.75rem;">{dots}</div>
    </div>
    <div style="color:#94A3B8;font-size:.88rem;line-height:1.8;white-space:pre-line;">{step["body"]}</div>
</div>
<div style="text-align:center;color:#334155;font-size:.72rem;margin-bottom:.5rem;">
    Step {step_idx+1} of {total}
</div>""", unsafe_allow_html=True)

    is_last = (step_idx == total - 1)
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        if is_last:
            if st.button("🚀 Start Sourcing!", type="primary",
                          use_container_width=True, key="ob_finish"):
                _complete(user.id)
        else:
            if st.button(f"Next →  ({step_idx+2}/{total})", type="primary",
                          use_container_width=True, key=f"ob_next_{step_idx}"):
                complete_onboarding_step(user.id, step["id"])
                st.session_state.onboarding_step += 1
                st.rerun()
    with col3:
        if not is_last:
            if st.button("Skip all", use_container_width=True, key="ob_skip"):
                _complete(user.id)
    return True


def _complete(user_id: str):
    mark_onboarding_complete(user_id)
    if st.session_state.get("profile"):
        st.session_state.profile["onboarding_completed"] = True
    st.session_state.onboarding_step = len(STEPS)
    st.rerun()
