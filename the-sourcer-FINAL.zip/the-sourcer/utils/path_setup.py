import sys
import os

def setup_path():
    """Ensure the project root is in sys.path."""
    # When running from pages/ subdirectory, the root may not be in path
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if root not in sys.path:
        sys.path.insert(0, root)
