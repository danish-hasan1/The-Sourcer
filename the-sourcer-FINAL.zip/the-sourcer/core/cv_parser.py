"""
core/cv_parser.py
AI-powered CV/Resume parser.
Accepts PDF or text, returns structured candidate dict.
"""
import streamlit as st
from typing import Dict, Optional
import json
import re


_CV_PARSE_SYSTEM = """You are an expert CV/Resume parser. Extract structured information from the CV text.

Return ONLY valid JSON — no markdown, no explanation:
{
  "full_name": "string",
  "current_title": "string",
  "location": "string",
  "email": "string",
  "phone": "string",
  "linkedin_url": "string",
  "github_url": "string",
  "summary": "string (2-3 sentence professional summary)",
  "experience_years": number,
  "skills": ["string"],
  "languages": ["string"],
  "education": [{"degree": "string", "institution": "string", "year": "string"}],
  "work_history": [
    {"title": "string", "company": "string", "duration": "string", "highlights": ["string"]}
  ],
  "certifications": ["string"],
  "seniority_estimate": "entry|mid|senior|lead|head|principal"
}

Rules:
- Extract ALL skills mentioned anywhere in the CV
- Estimate experience_years from work history dates
- If a field is not found, use null or empty array
- For linkedin_url: look for linkedin.com/in/ links
- For github_url: look for github.com/ links"""


def parse_cv_text(provider: str, api_key: str, cv_text: str) -> Optional[Dict]:
    """Parse a CV text string into a structured candidate dict."""
    from core.ai_engine import _call_ai, _parse_json

    if not cv_text.strip():
        return None

    # Truncate very long CVs to avoid token limits
    truncated = cv_text[:8000] if len(cv_text) > 8000 else cv_text

    raw = _call_ai(provider, api_key, _CV_PARSE_SYSTEM,
                   f"Parse this CV:\n\n{truncated}", max_tokens=2000)
    if not raw:
        return None

    parsed = _parse_json(raw)
    if not parsed:
        return None

    # Convert to candidate record format
    return {
        "full_name":       parsed.get("full_name", ""),
        "current_title":   parsed.get("current_title", ""),
        "location":        parsed.get("location", ""),
        "email":           parsed.get("email", ""),
        "source":          "CV Upload",
        "source_icon":     "📄",
        "profile_url":     parsed.get("linkedin_url", "") or parsed.get("github_url", ""),
        "skills":          parsed.get("skills", [])[:15],
        "experience_years": parsed.get("experience_years"),
        "summary":         parsed.get("summary", ""),
        "match_score":     0,
        "stage":           "sourced",
        "raw_data": {
            "cv_parsed":     True,
            "education":     parsed.get("education", []),
            "work_history":  parsed.get("work_history", []),
            "certifications": parsed.get("certifications", []),
            "seniority":     parsed.get("seniority_estimate", ""),
            "phone":         parsed.get("phone", ""),
            "github_url":    parsed.get("github_url", ""),
            "languages":     parsed.get("languages", []),
        },
    }


def extract_text_from_pdf(uploaded_file) -> str:
    """Extract text from an uploaded PDF file."""
    try:
        import io
        pdf_bytes = uploaded_file.read()

        # Try pypdf first
        try:
            from pypdf import PdfReader
            reader = PdfReader(io.BytesIO(pdf_bytes))
            text = "\n".join(
                page.extract_text() or ""
                for page in reader.pages
            )
            if text.strip():
                return text
        except ImportError:
            pass

        # Fallback: try pdfplumber
        try:
            import pdfplumber
            with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
                text = "\n".join(
                    page.extract_text() or ""
                    for page in pdf.pages
                )
            if text.strip():
                return text
        except ImportError:
            pass

        # Last resort: raw bytes decode attempt
        return pdf_bytes.decode("utf-8", errors="ignore")

    except Exception as e:
        st.error(f"Could not read PDF: {e}")
        return ""


def score_cv_against_matrix(provider: str, api_key: str,
                              parsed_cv: Dict, skill_matrix: Dict) -> Dict:
    """Score a parsed CV against an existing skill matrix."""
    from core.ai_engine import score_candidate

    snippet = f"""
Name: {parsed_cv.get('full_name', '')}
Title: {parsed_cv.get('current_title', '')}
Experience: {parsed_cv.get('experience_years', '?')} years
Skills: {', '.join(parsed_cv.get('skills', []))}
Summary: {parsed_cv.get('summary', '')[:400]}
Seniority: {parsed_cv.get('raw_data', {}).get('seniority', '')}
"""
    result = score_candidate(provider, api_key, snippet, skill_matrix)
    return result or {"match_score": 0, "rationale": "Could not score."}
