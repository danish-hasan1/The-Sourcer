import streamlit as st
from typing import List, Dict, Optional
from core.sources.google_xray import (
    xray_linkedin, xray_job_board, xray_cv_sites,
    get_boards_for_regions, REGIONAL_BOARDS,
)
from core.sources.github_source import search_github
from core.sources.stackoverflow_source import search_stackoverflow
from utils.deduplication import deduplicate_candidates
from core.ai_engine import score_candidate

def run_sourcing(
    search_params: Dict,
    filters: Dict,
    selected_sources: List[str],
    google_api_key: str = "",
    google_cse_id: str = "",
    github_token: str = "",
    anthropic_key: str = "",
    ai_provider: str = "anthropic",
    serp_api_key: str = "",
    skill_matrix: Dict = None,
    max_per_source: int = 20,
) -> List[Dict]:
    """
    Main sourcing orchestrator.
    SerpAPI takes priority over Google CSE for X-Ray searches.
    Returns a unified, deduplicated, AI-scored candidate list.
    """
    all_candidates = []

    boolean_strings  = search_params.get("boolean_strings", {})
    primary_boolean  = filters.get("boolean_string") or boolean_strings.get("primary", "")
    broad_boolean    = boolean_strings.get("broad", primary_boolean)
    location         = (filters.get("location","") or
                        search_params.get("locations",{}).get("primary",""))
    skills_core      = (filters.get("skills",[]) or
                        search_params.get("skills",{}).get("core",[]))

    # Search API availability
    has_serp   = bool(serp_api_key)
    has_google = bool(google_api_key and google_cse_id)
    has_search = has_serp or has_google

    search_backend = "SerpAPI" if has_serp else "Google CSE" if has_google else None

    # ── LinkedIn X-Ray ────────────────────────────────────────────────────────
    if "LinkedIn (X-Ray)" in selected_sources and has_search:
        with st.spinner(f"🔵 Searching LinkedIn via {search_backend}…"):
            results = xray_linkedin(
                boolean_string=filters.get("boolean_string") or boolean_strings.get("narrow", primary_boolean),
                location=location,
                serp_api_key=serp_api_key,
                api_key=google_api_key,
                cse_id=google_cse_id,
                max_results=max_per_source,
            )
            all_candidates.extend(results)
            st.toast(f"🔵 LinkedIn: {len(results)} found", icon="✅")

    # ── GitHub ────────────────────────────────────────────────────────────────
    if "GitHub" in selected_sources:
        with st.spinner("🐙 Searching GitHub…"):
            results = search_github(
                skills=skills_core[:5],
                location=location,
                token=github_token,
                max_results=max_per_source,
            )
            all_candidates.extend(results)
            st.toast(f"🐙 GitHub: {len(results)} found", icon="✅")

    # ── Stack Overflow ────────────────────────────────────────────────────────
    if "Stack Overflow" in selected_sources:
        with st.spinner("📚 Searching Stack Overflow…"):
            results = search_stackoverflow(
                skills=skills_core[:4],
                location=location,
                max_results=max_per_source,
            )
            all_candidates.extend(results)
            st.toast(f"📚 Stack Overflow: {len(results)} found", icon="✅")

    # ── Regional Job Boards ───────────────────────────────────────────────────
    if "Job Boards" in selected_sources and has_search:
        regions = filters.get("regions",[]) or _infer_regions(location)
        boards  = get_boards_for_regions(regions) or get_boards_for_regions(["Global"])
        for board in boards[:4]:
            with st.spinner(f"📋 Searching {board['name']}…"):
                results = xray_job_board(
                    board_domain=board["domain"],
                    boolean_string=broad_boolean,
                    board_name=board["name"],
                    serp_api_key=serp_api_key,
                    api_key=google_api_key,
                    cse_id=google_cse_id,
                    max_results=8,
                )
                all_candidates.extend(results)
                if results:
                    st.toast(f"📋 {board['name']}: {len(results)} found", icon="✅")

    # ── Web CVs ───────────────────────────────────────────────────────────────
    if "Web CVs" in selected_sources and has_search:
        with st.spinner("📄 Searching for CVs…"):
            results = xray_cv_sites(
                boolean_string=broad_boolean,
                serp_api_key=serp_api_key,
                api_key=google_api_key,
                cse_id=google_cse_id,
                max_results=10,
            )
            all_candidates.extend(results)
            if results:
                st.toast(f"📄 Web CVs: {len(results)} found", icon="✅")

    # ── No search API warning ─────────────────────────────────────────────────
    if not has_search and any(s in selected_sources for s in ["LinkedIn (X-Ray)","Job Boards","Web CVs"]):
        st.warning(
            "⚠️ **No search API configured.** LinkedIn X-Ray, Job Boards, and Web CVs require "
            "a SerpAPI key or Google Custom Search API key. Add one in **Settings → Search Keys**."
        )

    # ── Deduplication ─────────────────────────────────────────────────────────
    candidates = deduplicate_candidates(all_candidates)

    # ── AI Scoring ────────────────────────────────────────────────────────────
    if anthropic_key and skill_matrix and candidates:
        scored = []
        progress = st.progress(0, text=f"🎯 Scoring {len(candidates)} candidates…")
        for i, candidate in enumerate(candidates):
            progress.progress((i+1)/len(candidates),
                              text=f"🎯 Scoring {i+1}/{len(candidates)}…")
            snippet = (
                f"Name: {candidate.get('full_name','')}\n"
                f"Title: {candidate.get('current_title','')}\n"
                f"Location: {candidate.get('location','')}\n"
                f"Skills: {', '.join(candidate.get('skills',[]))}\n"
                f"Summary: {(candidate.get('summary',''))[:400]}"
            )
            result = score_candidate(ai_provider, anthropic_key, snippet, skill_matrix)
            if result:
                candidate["match_score"]    = result.get("match_score", 0)
                candidate["ai_rationale"]   = result.get("rationale", "")
                candidate["recommendation"] = result.get("recommendation", "")
                candidate["matched_skills"] = result.get("matched_skills", [])
                candidate["missing_skills"] = result.get("missing_skills", [])
            scored.append(candidate)
        progress.empty()
        candidates = scored

    candidates.sort(key=lambda x: x.get("match_score", 0), reverse=True)
    return candidates

def _infer_regions(location: str) -> List[str]:
    loc = location.lower()
    for key, region in [
        ("india","India"),("delhi","India"),("mumbai","India"),("bangalore","India"),("hyderabad","India"),
        ("spain","Spain"),("madrid","Spain"),("barcelona","Spain"),
        ("uk","UK"),("london","UK"),("manchester","UK"),("england","UK"),("scotland","UK"),
        ("us","USA"),("usa","USA"),("new york","USA"),("san francisco","USA"),("chicago","USA"),
        ("dubai","Middle East"),("uae","Middle East"),("riyadh","Middle East"),("abu dhabi","Middle East"),
        ("germany","Germany"),("berlin","Germany"),("munich","Germany"),("frankfurt","Germany"),
        ("france","France"),("paris","France"),
    ]:
        if key in loc:
            return [region, "Global"]
    return ["Global"]

def get_source_options() -> List[str]:
    return ["LinkedIn (X-Ray)", "GitHub", "Stack Overflow", "Job Boards", "Web CVs"]

def get_all_regions() -> List[str]:
    return list(REGIONAL_BOARDS.keys())
