"""
core/auth.py — Authentication & API key helpers for The Sourcer.
"""
import streamlit as st
from typing import Optional, Dict
import time


def get_supabase():
    from core.database import get_supabase as _get
    return _get()


def sign_up(email: str, password: str, full_name: str) -> Dict:
    try:
        sb  = get_supabase()
        res = sb.auth.sign_up({
            "email":    email,
            "password": password,
            "options":  {"data": {"full_name": full_name}},
        })
        if res.user:
            return {"success": True, "user": res.user}
        return {"success": False, "error": "Signup failed — please try again."}
    except Exception as e:
        err = str(e)
        if "already registered" in err.lower() or "already exists" in err.lower():
            return {"success": False, "error": "Email already registered — please sign in."}
        if "database error" in err.lower():
            return {"success": False,
                    "error": "Database setup issue. Admin: run signup_fix.sql in Supabase SQL Editor."}
        return {"success": False, "error": err}


def sign_in(email: str, password: str) -> Dict:
    try:
        sb  = get_supabase()
        res = sb.auth.sign_in_with_password({"email": email, "password": password})
        if res.user and res.session:
            return {"success": True, "user": res.user, "session": res.session}
        return {"success": False, "error": "Invalid email or password."}
    except Exception as e:
        return {"success": False, "error": "Invalid email or password."}


def sign_out():
    try:
        get_supabase().auth.sign_out()
    except Exception:
        pass
    for k in ["user","profile","api_keys","supabase_client",
              "ai_results","search_filters","sourcing_results",
              "search_id","current_jd_id","outreach_candidate",
              "generated_msg","generated_subject"]:
        st.session_state.pop(k, None)
    st.rerun()


def is_authenticated() -> bool:
    return bool(st.session_state.get("user"))


def is_admin() -> bool:
    return (st.session_state.get("profile") or {}).get("role") == "admin"


def require_auth():
    if not is_authenticated():
        st.switch_page("pages/01_Login.py")


def load_user_session(user_id: str):
    from core.database import get_profile, get_api_keys
    if not st.session_state.get("profile"):
        profile = get_profile(user_id)
        if not profile:
            time.sleep(1.2)
            profile = get_profile(user_id)
        if not profile:
            _create_profile_fallback(user_id)
            time.sleep(0.5)
            profile = get_profile(user_id)
        st.session_state.profile = profile or {}
    if not st.session_state.get("api_keys"):
        st.session_state.api_keys = get_api_keys(user_id) or {}


def _create_profile_fallback(user_id: str):
    try:
        sb        = get_supabase()
        user_data = sb.auth.get_user()
        email, full_name = "", ""
        if user_data and user_data.user:
            email     = user_data.user.email or ""
            full_name = (user_data.user.user_metadata or {}).get("full_name", "")
        sb.table("profiles").upsert(
            {"id": user_id, "email": email, "full_name": full_name,
             "role": "user", "onboarding_completed": False},
            on_conflict="id",
        ).execute()
        sb.table("onboarding").upsert(
            {"user_id": user_id, "completed_steps": []},
            on_conflict="user_id",
        ).execute()
    except Exception:
        pass


# ── Key helpers — read active provider + key from session ─────────────────────

def get_ai_provider() -> str:
    """Return the user's chosen AI provider slug."""
    keys = st.session_state.get("api_keys") or {}
    return keys.get("ai_provider") or "anthropic"


def get_ai_key() -> Optional[str]:
    """Return the API key for the active provider."""
    keys     = st.session_state.get("api_keys") or {}
    provider = get_ai_provider()
    key_map  = {
        "anthropic": "anthropic_key",
        "openai":    "openai_key",
        "groq":      "groq_key",
        "mistral":   "mistral_key",
    }
    col = key_map.get(provider, "anthropic_key")
    return keys.get(col) or st.secrets.get("ANTHROPIC_KEY_DEFAULT", None)


# Keep legacy name for backward compat with older pages
def get_anthropic_key() -> Optional[str]:
    return get_ai_key()


def get_google_keys() -> Dict:
    keys = st.session_state.get("api_keys") or {}
    return {
        "cse_id":    keys.get("google_cse_id", ""),
        "api_key":   keys.get("google_api_key", ""),
        "serp_key":  keys.get("serp_api_key", ""),
    }


def get_github_token() -> Optional[str]:
    return (st.session_state.get("api_keys") or {}).get("github_token", "")
