"""
core/search_templates.py
Pre-built search templates for common role archetypes.
One click loads titles, skills, Boolean strings, and regional boards.
"""
from typing import Dict, List

TEMPLATES: List[Dict] = [
    {
        "id":          "software_engineer",
        "label":       "Software Engineer",
        "icon":        "💻",
        "category":    "Technology",
        "description": "Full-stack, backend, or frontend software development roles",
        "job_titles": [
            "Software Engineer", "Software Developer", "Full Stack Engineer",
            "Backend Engineer", "Frontend Engineer", "Senior Software Engineer",
        ],
        "skills": [
            "Python", "JavaScript", "TypeScript", "React", "Node.js",
            "AWS", "Docker", "Kubernetes", "SQL", "REST APIs",
        ],
        "boolean_string": '("software engineer" OR "software developer" OR "full stack" OR "backend engineer") AND (python OR javascript OR react OR node)',
        "seniority":       "mid",
        "experience_min":  2,
        "experience_max":  10,
        "industries":      ["SaaS", "Fintech", "E-commerce", "B2B Software"],
        "regions":         ["Global", "UK", "India", "USA"],
    },
    {
        "id":          "product_manager",
        "label":       "Product Manager",
        "icon":        "📱",
        "category":    "Product",
        "description": "Product strategy, roadmap ownership, and cross-functional leadership",
        "job_titles": [
            "Product Manager", "Senior Product Manager", "Product Owner",
            "Group Product Manager", "Head of Product", "VP Product",
        ],
        "skills": [
            "Product Strategy", "Roadmap Planning", "Agile", "Scrum",
            "A/B Testing", "User Research", "SQL", "Jira", "Figma",
            "Stakeholder Management", "OKRs",
        ],
        "boolean_string": '("product manager" OR "product owner" OR "head of product") AND (roadmap OR agile OR "user research" OR "product strategy")',
        "seniority":       "senior",
        "experience_min":  4,
        "experience_max":  12,
        "industries":      ["SaaS", "Consumer Tech", "Fintech", "Marketplace"],
        "regions":         ["Global", "UK", "USA"],
    },
    {
        "id":          "data_scientist",
        "label":       "Data Scientist",
        "icon":        "📊",
        "category":    "Data",
        "description": "Machine learning, statistical analysis, and data modelling",
        "job_titles": [
            "Data Scientist", "Senior Data Scientist", "ML Engineer",
            "Machine Learning Engineer", "AI Engineer", "Research Scientist",
        ],
        "skills": [
            "Python", "Machine Learning", "TensorFlow", "PyTorch", "Scikit-learn",
            "SQL", "Statistics", "NLP", "Deep Learning", "Data Analysis", "R",
        ],
        "boolean_string": '("data scientist" OR "machine learning engineer" OR "ML engineer" OR "AI engineer") AND (python OR tensorflow OR pytorch OR "machine learning")',
        "seniority":       "mid",
        "experience_min":  2,
        "experience_max":  8,
        "industries":      ["Tech", "Finance", "Healthcare", "Research"],
        "regions":         ["Global", "UK", "USA", "Germany"],
    },
    {
        "id":          "devops_engineer",
        "label":       "DevOps / SRE",
        "icon":        "⚙️",
        "category":    "Technology",
        "description": "Infrastructure, CI/CD, cloud, and site reliability",
        "job_titles": [
            "DevOps Engineer", "Site Reliability Engineer", "SRE",
            "Platform Engineer", "Cloud Engineer", "Infrastructure Engineer",
        ],
        "skills": [
            "AWS", "Azure", "GCP", "Kubernetes", "Docker", "Terraform",
            "CI/CD", "Jenkins", "GitHub Actions", "Linux", "Python", "Ansible",
        ],
        "boolean_string": '("devops engineer" OR "site reliability engineer" OR "SRE" OR "platform engineer" OR "cloud engineer") AND (kubernetes OR docker OR terraform OR aws)',
        "seniority":       "mid",
        "experience_min":  3,
        "experience_max":  10,
        "industries":      ["SaaS", "Tech", "Finance", "E-commerce"],
        "regions":         ["Global", "UK", "USA", "Germany"],
    },
    {
        "id":          "sales_executive",
        "label":       "Sales Executive",
        "icon":        "💼",
        "category":    "Sales",
        "description": "B2B sales, account executive, or enterprise sales roles",
        "job_titles": [
            "Account Executive", "Sales Executive", "Enterprise AE",
            "Senior AE", "Sales Manager", "Business Development Manager",
        ],
        "skills": [
            "B2B Sales", "SaaS Sales", "CRM", "Salesforce", "Pipeline Management",
            "Negotiation", "Cold Calling", "Account Management", "HubSpot",
        ],
        "boolean_string": '("account executive" OR "sales executive" OR "enterprise sales" OR "business development") AND (saas OR b2b OR salesforce OR "pipeline")',
        "seniority":       "mid",
        "experience_min":  3,
        "experience_max":  10,
        "industries":      ["SaaS", "Software", "Tech", "B2B"],
        "regions":         ["Global", "UK", "USA"],
    },
    {
        "id":          "recruiter_ta",
        "label":       "Talent Acquisition",
        "icon":        "🎯",
        "category":    "HR & People",
        "description": "In-house recruiter, talent partner, or TA specialist",
        "job_titles": [
            "Talent Acquisition Specialist", "Technical Recruiter",
            "In-house Recruiter", "Talent Partner", "Senior Recruiter",
            "Head of Talent", "TA Manager",
        ],
        "skills": [
            "Talent Acquisition", "Sourcing", "Boolean Search", "LinkedIn Recruiter",
            "ATS", "Interviewing", "Employer Branding", "Headhunting",
        ],
        "boolean_string": '("talent acquisition" OR "technical recruiter" OR "in-house recruiter" OR "talent partner") AND (sourcing OR linkedin OR ats OR "boolean")',
        "seniority":       "mid",
        "experience_min":  2,
        "experience_max":  8,
        "industries":      ["Tech", "SaaS", "Recruitment", "Agency"],
        "regions":         ["Global", "UK", "USA"],
    },
    {
        "id":          "finance_analyst",
        "label":       "Finance Analyst",
        "icon":        "💰",
        "category":    "Finance",
        "description": "Financial analysis, FP&A, investment, and accounting",
        "job_titles": [
            "Financial Analyst", "FP&A Analyst", "Investment Analyst",
            "Finance Manager", "Senior Financial Analyst", "Chartered Accountant",
        ],
        "skills": [
            "Financial Modelling", "Excel", "FP&A", "Budgeting", "Forecasting",
            "SQL", "Power BI", "Tableau", "IFRS", "Variance Analysis",
        ],
        "boolean_string": '("financial analyst" OR "FP&A" OR "investment analyst" OR "finance manager") AND ("financial modelling" OR excel OR forecasting OR budgeting)',
        "seniority":       "mid",
        "experience_min":  2,
        "experience_max":  8,
        "industries":      ["Finance", "Banking", "Investment", "Corporate"],
        "regions":         ["Global", "UK", "USA", "Middle East"],
    },
    {
        "id":          "ux_designer",
        "label":       "UX / Product Designer",
        "icon":        "🎨",
        "category":    "Design",
        "description": "UX research, UI design, and product design",
        "job_titles": [
            "UX Designer", "Product Designer", "UI/UX Designer",
            "Senior UX Designer", "Lead Designer", "Design Lead",
        ],
        "skills": [
            "Figma", "User Research", "Wireframing", "Prototyping",
            "Design Systems", "Usability Testing", "Adobe XD", "Sketch",
        ],
        "boolean_string": '("UX designer" OR "product designer" OR "UI designer" OR "UX researcher") AND (figma OR "user research" OR wireframing OR prototyping)',
        "seniority":       "mid",
        "experience_min":  2,
        "experience_max":  8,
        "industries":      ["Tech", "SaaS", "Agency", "E-commerce"],
        "regions":         ["Global", "UK", "USA"],
    },
    {
        "id":          "marketing_manager",
        "label":       "Marketing Manager",
        "icon":        "📣",
        "category":    "Marketing",
        "description": "Digital marketing, growth, demand generation",
        "job_titles": [
            "Marketing Manager", "Digital Marketing Manager",
            "Growth Manager", "Demand Generation Manager",
            "Head of Marketing", "Performance Marketing Manager",
        ],
        "skills": [
            "Digital Marketing", "SEO", "SEM", "Google Ads", "Content Marketing",
            "Marketing Automation", "HubSpot", "CRM", "Analytics", "Copywriting",
        ],
        "boolean_string": '("marketing manager" OR "growth manager" OR "demand generation" OR "digital marketing") AND (seo OR "google ads" OR "marketing automation" OR hubspot)',
        "seniority":       "mid",
        "experience_min":  3,
        "experience_max":  8,
        "industries":      ["SaaS", "E-commerce", "Consumer", "B2B"],
        "regions":         ["Global", "UK", "USA"],
    },
    {
        "id":          "data_engineer",
        "label":       "Data Engineer",
        "icon":        "🔧",
        "category":    "Data",
        "description": "Data pipelines, warehousing, ETL, and infrastructure",
        "job_titles": [
            "Data Engineer", "Senior Data Engineer", "Analytics Engineer",
            "Data Platform Engineer", "ETL Developer",
        ],
        "skills": [
            "Python", "SQL", "Apache Spark", "Airflow", "dbt", "Snowflake",
            "BigQuery", "Redshift", "Kafka", "ETL", "AWS", "Databricks",
        ],
        "boolean_string": '("data engineer" OR "analytics engineer" OR "data platform engineer") AND (python OR spark OR airflow OR dbt OR snowflake OR kafka)',
        "seniority":       "mid",
        "experience_min":  2,
        "experience_max":  8,
        "industries":      ["Tech", "Finance", "E-commerce", "Data"],
        "regions":         ["Global", "UK", "USA", "Germany"],
    },
    {
        "id":          "hr_manager",
        "label":       "HR Manager / HRBP",
        "icon":        "👥",
        "category":    "HR & People",
        "description": "HR business partner, generalist, or people operations",
        "job_titles": [
            "HR Manager", "HR Business Partner", "HRBP",
            "People Partner", "HR Generalist", "Head of People",
        ],
        "skills": [
            "Employee Relations", "Performance Management", "HRIS", "Workday",
            "Compensation", "L&D", "HR Policy", "Employment Law",
        ],
        "boolean_string": '("HR manager" OR "HR business partner" OR "HRBP" OR "people partner" OR "head of people") AND ("employee relations" OR "performance management" OR hris)',
        "seniority":       "mid",
        "experience_min":  3,
        "experience_max":  10,
        "industries":      ["Tech", "Finance", "Healthcare", "Corporate"],
        "regions":         ["Global", "UK", "USA"],
    },
    {
        "id":          "cybersecurity",
        "label":       "Cybersecurity",
        "icon":        "🔒",
        "category":    "Technology",
        "description": "Security engineering, pentesting, and InfoSec",
        "job_titles": [
            "Security Engineer", "Cybersecurity Analyst", "Penetration Tester",
            "Information Security Manager", "CISO", "Cloud Security Engineer",
        ],
        "skills": [
            "Penetration Testing", "SIEM", "SOC", "Incident Response",
            "Cloud Security", "ISO 27001", "CISSP", "Python", "Network Security",
        ],
        "boolean_string": '("security engineer" OR "cybersecurity" OR "penetration tester" OR "infosec") AND (siem OR "penetration testing" OR "incident response" OR cissp)',
        "seniority":       "mid",
        "experience_min":  3,
        "experience_max":  10,
        "industries":      ["Finance", "Tech", "Government", "Healthcare"],
        "regions":         ["Global", "UK", "USA"],
    },
]

CATEGORIES = sorted(set(t["category"] for t in TEMPLATES))


def get_templates_by_category(category: str = None):
    if category and category != "All":
        return [t for t in TEMPLATES if t["category"] == category]
    return TEMPLATES


def get_template(template_id: str):
    return next((t for t in TEMPLATES if t["id"] == template_id), None)
