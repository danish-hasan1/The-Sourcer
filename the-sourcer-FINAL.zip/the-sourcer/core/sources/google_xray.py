import requests
import streamlit as st
from typing import List, Dict, Optional
import re
import time

# ── Unified search backend ─────────────────────────────────────────────────────

def _serp_search(query: str, serp_api_key: str, num: int = 10) -> List[Dict]:
    """Execute a search via SerpAPI — returns normalised result items."""
    if not serp_api_key:
        return []
    try:
        resp = requests.get(
            "https://serpapi.com/search",
            params={
                "q":       query,
                "api_key": serp_api_key,
                "engine":  "google",
                "num":     min(num, 10),
                "hl":      "en",
            },
            timeout=15,
        )
        if resp.status_code == 200:
            data = resp.json()
            # Normalise to same shape as Google CSE items
            items = []
            for r in data.get("organic_results", [])[:num]:
                items.append({
                    "link":    r.get("link", ""),
                    "title":   r.get("title", ""),
                    "snippet": r.get("snippet", ""),
                })
            return items
        elif resp.status_code == 401:
            st.warning("⚠️ SerpAPI key is invalid. Check it in Settings.")
        elif resp.status_code == 429:
            st.warning("⚠️ SerpAPI quota reached. Upgrade at serpapi.com or switch to Google CSE.")
    except Exception as e:
        st.warning(f"SerpAPI error: {e}")
    return []

def _google_cse_search(query: str, api_key: str, cse_id: str,
                        num: int = 10, start: int = 1) -> List[Dict]:
    """Execute a Google Custom Search query."""
    if not api_key or not cse_id:
        return []
    try:
        resp = requests.get(
            "https://www.googleapis.com/customsearch/v1",
            params={"key": api_key, "cx": cse_id, "q": query,
                    "num": min(num, 10), "start": start},
            timeout=12,
        )
        if resp.status_code == 200:
            return resp.json().get("items", [])
        elif resp.status_code == 429:
            st.warning("⚠️ Google CSE quota reached for today (100/day free limit).")
        elif resp.status_code == 400:
            st.warning("⚠️ Google CSE configuration error — check your API key and Search Engine ID.")
    except Exception:
        pass
    return []

def _search(query: str, serp_api_key: str = "", google_api_key: str = "",
            google_cse_id: str = "", num: int = 10, start: int = 1) -> List[Dict]:
    """
    Unified search: tries SerpAPI first, falls back to Google CSE.
    Always pass both keys — whichever is set will be used.
    """
    # Prefer SerpAPI when available
    if serp_api_key:
        results = _serp_search(query, serp_api_key, num=num)
        if results:
            return results
    # Fallback to Google CSE
    if google_api_key and google_cse_id:
        return _google_cse_search(query, google_api_key, google_cse_id, num=num, start=start)
    return []

# ── Result parsers ─────────────────────────────────────────────────────────────

def _parse_linkedin_result(item: Dict) -> Optional[Dict]:
    """Parse a search result item into a LinkedIn candidate record."""
    link    = item.get("link", "")
    title   = item.get("title", "")
    snippet = item.get("snippet", "")

    if "linkedin.com/in/" not in link:
        return None

    name, current_title = "", ""
    if " - " in title:
        parts        = title.split(" - ", 1)
        name         = parts[0].strip()
        current_title = parts[1].replace("| LinkedIn","").replace("- LinkedIn","").strip()
    elif "| LinkedIn" in title:
        name = title.replace("| LinkedIn","").strip()

    location = ""
    for pattern in [r"\b([A-Z][a-z]+(?:,\s*[A-Z][a-z]+)*)\s*·", r"Location:\s*([^\n·]+)"]:
        m = re.search(pattern, snippet)
        if m:
            location = m.group(1).strip()
            break

    tech_kws = ["Python","Java","React","Node","SQL","AWS","Azure","ML","AI","Kubernetes",
                "Docker","Salesforce","SAP","Product","Agile","Scrum","Marketing","Finance",
                "Strategy","Management","Leadership","Data","TypeScript","Go","Rust","Swift"]
    skills = [kw for kw in tech_kws
              if kw.lower() in snippet.lower() or kw.lower() in title.lower()]

    return {
        "full_name":     name,
        "current_title": current_title,
        "location":      location,
        "source":        "LinkedIn (X-Ray)",
        "source_icon":   "🔵",
        "source_group":  "LinkedIn",
        "profile_url":   link,
        "summary":       snippet,
        "skills":        skills[:8],
        "match_score":   0,
        "raw_data":      {"title": title, "snippet": snippet, "link": link},
    }

# ── Public search functions ────────────────────────────────────────────────────

def xray_linkedin(
    boolean_string: str,
    location: str = "",
    serp_api_key: str = "",
    api_key: str = "",        # Google CSE API key
    cse_id: str = "",         # Google CSE ID
    max_results: int = 20,
) -> List[Dict]:
    """X-Ray LinkedIn profiles — works with SerpAPI or Google CSE."""
    location_part = f'"{location}"' if location else ""
    query = f'site:linkedin.com/in/ {location_part} {boolean_string}'.strip()

    results = []
    # Two pages for Google CSE, one pass for SerpAPI
    passes = [1, 11] if (api_key and cse_id and not serp_api_key) else [1]
    for start in passes:
        if len(results) >= max_results:
            break
        items = _search(query, serp_api_key=serp_api_key,
                         google_api_key=api_key, google_cse_id=cse_id,
                         num=10, start=start)
        for item in items:
            parsed = _parse_linkedin_result(item)
            if parsed:
                results.append(parsed)
        if len(items) < 10:
            break
        time.sleep(0.3)

    return results[:max_results]

def xray_job_board(
    board_domain: str,
    boolean_string: str,
    board_name: str = "",
    serp_api_key: str = "",
    api_key: str = "",
    cse_id: str = "",
    max_results: int = 10,
) -> List[Dict]:
    """X-Ray any job board — works with SerpAPI or Google CSE."""
    query = f'site:{board_domain} {boolean_string} resume OR cv OR profile'
    items = _search(query, serp_api_key=serp_api_key,
                    google_api_key=api_key, google_cse_id=cse_id, num=max_results)
    results = []
    for item in items:
        link    = item.get("link","")
        title   = item.get("title","")
        snippet = item.get("snippet","")
        results.append({
            "full_name":     title.split("-")[0].strip() if "-" in title else title,
            "current_title": title.split("-")[1].strip() if "-" in title and len(title.split("-"))>1 else "",
            "location":      "",
            "source":        board_name or board_domain,
            "source_icon":   "📋",
            "source_group":  "Job Boards",
            "profile_url":   link,
            "summary":       snippet,
            "skills":        [],
            "match_score":   0,
            "raw_data":      {"title": title, "snippet": snippet},
        })
    return results

def xray_cv_sites(
    boolean_string: str,
    serp_api_key: str = "",
    api_key: str = "",
    cse_id: str = "",
    max_results: int = 10,
) -> List[Dict]:
    """Search for public CVs/resumes across the open web."""
    query = f'({boolean_string}) filetype:pdf OR filetype:doc (resume OR cv OR "curriculum vitae")'
    items = _search(query, serp_api_key=serp_api_key,
                    google_api_key=api_key, google_cse_id=cse_id, num=max_results)
    results = []
    for item in items:
        results.append({
            "full_name":     item.get("title","").replace("Resume","").replace("CV","").strip(),
            "current_title": "",
            "location":      "",
            "source":        "Web CV",
            "source_icon":   "📄",
            "source_group":  "Web CVs",
            "profile_url":   item.get("link",""),
            "summary":       item.get("snippet",""),
            "skills":        [],
            "match_score":   0,
            "raw_data":      {},
        })
    return results

# ── Regional job board registry ────────────────────────────────────────────────

REGIONAL_BOARDS = {
    "India":       [{"domain":"naukri.com","name":"Naukri"},
                    {"domain":"shine.com","name":"Shine"},
                    {"domain":"timesjobs.com","name":"TimesJobs"}],
    "Spain":       [{"domain":"infojobs.net","name":"InfoJobs"},
                    {"domain":"tecnoempleo.com","name":"Tecnoempleo"}],
    "UK":          [{"domain":"reed.co.uk","name":"Reed"},
                    {"domain":"totaljobs.com","name":"Totaljobs"},
                    {"domain":"cv-library.co.uk","name":"CV-Library"}],
    "USA":         [{"domain":"dice.com","name":"Dice"},
                    {"domain":"ziprecruiter.com","name":"ZipRecruiter"}],
    "Middle East": [{"domain":"bayt.com","name":"Bayt"},
                    {"domain":"naukrigulf.com","name":"NaukriGulf"}],
    "Germany":     [{"domain":"stepstone.de","name":"StepStone"},
                    {"domain":"xing.com","name":"Xing"}],
    "France":      [{"domain":"apec.fr","name":"APEC"},
                    {"domain":"cadremploi.fr","name":"Cadremploi"}],
    "Global":      [{"domain":"indeed.com","name":"Indeed"},
                    {"domain":"monster.com","name":"Monster"}],
}

def get_boards_for_regions(regions: List[str]) -> List[Dict]:
    boards, seen = [], set()
    for region in regions:
        for board in REGIONAL_BOARDS.get(region, []):
            if board["domain"] not in seen:
                boards.append(board)
                seen.add(board["domain"])
    return boards
