import json
import streamlit as st
from typing import Dict, Optional

# ── Provider registry ──────────────────────────────────────────────────────────
PROVIDER_INFO = {
    "anthropic": {
        "name":    "Anthropic Claude",
        "models":  ["claude-opus-4-5", "claude-sonnet-4-5", "claude-haiku-4-5-20251001"],
        "default": "claude-opus-4-5",
        "free":    False,
        "note":    "Best quality. Paid only — starts at $3/M tokens (Sonnet).",
        "icon":    "🤖",
        "pkg":     "anthropic",
    },
    "openai": {
        "name":    "OpenAI",
        "models":  ["gpt-4o-mini", "gpt-4o", "gpt-3.5-turbo"],
        "default": "gpt-4o-mini",
        "free":    False,
        "note":    "GPT-4o-mini is very affordable (~$0.15/M tokens).",
        "icon":    "🟢",
        "pkg":     "openai",
    },
    "groq": {
        "name":    "Groq (Llama)",
        "models":  ["llama-3.3-70b-versatile", "llama-3.1-8b-instant", "mixtral-8x7b-32768"],
        "default": "llama-3.3-70b-versatile",
        "free":    True,
        "note":    "FREE tier — 14,400 req/day. Best free option.",
        "icon":    "⚡",
        "pkg":     "groq",
    },
    "mistral": {
        "name":    "Mistral AI",
        "models":  ["mistral-small-latest", "open-mistral-7b"],
        "default": "mistral-small-latest",
        "free":    True,
        "note":    "Free tier via La Plateforme — open models.",
        "icon":    "🌊",
        "pkg":     "mistralai",
    },
}

def _call_ai(
    provider: str,
    api_key: str,
    system_prompt: str,
    user_content: str,
    max_tokens: int = 3000,
    model_override: str = "",
) -> Optional[str]:
    """
    Provider-agnostic AI call. All package imports are inside this function
    so a missing package only errors when that provider is actually used,
    not on module import.
    """
    if not api_key:
        st.error("No AI API key configured. Go to Settings to add one.")
        return None

    model = model_override or PROVIDER_INFO.get(provider, {}).get("default", "claude-opus-4-5")

    try:
        # ── Anthropic ─────────────────────────────────────────────────────────
        if provider == "anthropic":
            try:
                import anthropic as _anthropic
            except ImportError:
                st.error("Anthropic package not installed. Run: pip install anthropic")
                return None
            client = _anthropic.Anthropic(api_key=api_key)
            msg = client.messages.create(
                model=model,
                max_tokens=max_tokens,
                system=system_prompt,
                messages=[{"role": "user", "content": user_content}],
            )
            return msg.content[0].text

        # ── OpenAI ────────────────────────────────────────────────────────────
        elif provider == "openai":
            try:
                from openai import OpenAI as _OpenAI
            except ImportError:
                st.error("OpenAI package not installed. Run: pip install openai")
                return None
            client = _OpenAI(api_key=api_key)
            resp = client.chat.completions.create(
                model=model,
                max_tokens=max_tokens,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user",   "content": user_content},
                ],
            )
            return resp.choices[0].message.content

        # ── Groq ──────────────────────────────────────────────────────────────
        elif provider == "groq":
            try:
                from groq import Groq as _Groq
            except ImportError:
                st.error("Groq package not installed. Run: pip install groq")
                return None
            client = _Groq(api_key=api_key)
            resp = client.chat.completions.create(
                model=model,
                max_tokens=max_tokens,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user",   "content": user_content},
                ],
            )
            return resp.choices[0].message.content

        # ── Mistral ───────────────────────────────────────────────────────────
        elif provider == "mistral":
            try:
                from mistralai import Mistral as _Mistral
                client = _Mistral(api_key=api_key)
                resp = client.chat.complete(
                    model=model,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user",   "content": user_content},
                    ],
                )
                return resp.choices[0].message.content
            except ImportError:
                st.error("Mistral package not installed. Run: pip install mistralai")
                return None
            except Exception as me:
                # Fallback: older mistralai SDK
                try:
                    from mistralai.client import MistralClient
                    from mistralai.models.chat_completion import ChatMessage
                    client = MistralClient(api_key=api_key)
                    resp = client.chat(
                        model=model,
                        messages=[
                            ChatMessage(role="system", content=system_prompt),
                            ChatMessage(role="user",   content=user_content),
                        ],
                    )
                    return resp.choices[0].message.content
                except Exception:
                    raise me
        else:
            st.error(f"Unknown AI provider: '{provider}'. Choose one in Settings.")
            return None

    except Exception as e:
        err = str(e)
        if "auth" in err.lower() or "401" in err or "invalid_api_key" in err.lower():
            st.error(f"❌ Invalid {PROVIDER_INFO.get(provider,{}).get('name','AI')} API key. Check Settings.")
        elif "rate" in err.lower() or "429" in err:
            st.warning("⚠️ Rate limit reached. Wait a moment and try again.")
        elif "model" in err.lower() and "not found" in err.lower():
            st.error(f"⚠️ Model '{model}' not available on your plan.")
        elif "quota" in err.lower() or "billing" in err.lower():
            st.error("⚠️ API quota exceeded or billing issue. Check your provider dashboard.")
        else:
            st.error(f"AI error: {err[:200]}")
        return None

def _parse_json(raw: str) -> Optional[Dict]:
    """Strip markdown fences and parse JSON safely."""
    if not raw:
        return None
    clean = raw.strip()
    for fence in ["```json", "```JSON", "```"]:
        if clean.startswith(fence):
            clean = clean[len(fence):]
    clean = clean.strip().rstrip("`").strip()
    try:
        return json.loads(clean)
    except json.JSONDecodeError:
        start = clean.find("{")
        end   = clean.rfind("}") + 1
        if start >= 0 and end > start:
            try:
                return json.loads(clean[start:end])
            except Exception:
                pass
    return None

def _ai_json(provider: str, api_key: str, system: str, user: str,
             max_tokens: int = 3000) -> Optional[Dict]:
    """Call AI and parse JSON response."""
    raw = _call_ai(provider, api_key, system, user, max_tokens)
    if not raw:
        return None
    result = _parse_json(raw)
    return result if result is not None else {"raw": raw}

# ══════════════════════════════════════════════════════════════════════════════
# PROMPT 1 — JD UNDERSTANDING & INTENT EXTRACTION
# ══════════════════════════════════════════════════════════════════════════════
_P1 = """You are the original hiring decision-maker combined with a senior talent evaluator.
Understand the JD EXACTLY as intended — infer intent, priorities, and implicit requirements.
Do NOT summarise. Do NOT keyword-match. Assume the JD may be incomplete.
Respond ONLY with valid JSON:
{
  "role_objective": {"problem_solved": "string", "why_role_exists_now": "string"},
  "seniority": {"level": "entry|mid|senior|lead|head|principal", "ownership_degree": "string", "decision_making": "string"},
  "primary_competencies": [{"name": "string", "why_essential": "string"}],
  "secondary_competencies": [{"name": "string", "value": "string"}],
  "implicit_expectations": ["string"],
  "evaluation_signals": {"prioritized": ["string"], "disqualifiers": ["string"]},
  "ideal_candidate_brief": "string",
  "inferred_industry": "string",
  "inferred_company_type": "string",
  "suggested_job_title": "string"
}"""

def analyze_jd(provider: str, api_key: str, jd_text: str) -> Optional[Dict]:
    return _ai_json(provider, api_key, _P1, f"Job Description:\n\n{jd_text}")

# ══════════════════════════════════════════════════════════════════════════════
# PROMPT 2 — WEIGHTED SKILL SCORING MATRIX
# ══════════════════════════════════════════════════════════════════════════════
_P2 = """Build a weighted competency evaluation framework. Total must equal exactly 100 points.
Weight by actual importance, not mention frequency. Core skills carry most weight.
Respond ONLY with valid JSON:
{
  "skill_matrix": [
    {"skill": "string", "category": "core|secondary|implicit", "weight": number,
     "strong_evidence": "string", "weak_evidence": "string"}
  ],
  "weighting_rationale": "string",
  "seniority_sensitivity": {"junior_expectations": "string", "senior_differentiators": "string"},
  "non_negotiables": ["string"],
  "scoring_guide": {"strong_match": "85-100", "good_match": "65-84", "potential": "45-64", "weak_match": "below 45"}
}"""

def build_skill_matrix(provider: str, api_key: str, jd_analysis: Dict) -> Optional[Dict]:
    return _ai_json(provider, api_key, _P2,
                    f"Build matrix from this JD analysis:\n\n{json.dumps(jd_analysis, indent=2)}")

# ══════════════════════════════════════════════════════════════════════════════
# PROMPT 3 — SEARCH PARAMETERS & BOOLEAN BUILDER
# ══════════════════════════════════════════════════════════════════════════════
_P3 = """You are a senior sourcing recruiter. Convert role analysis into search parameters and Boolean strings.
Include title variants, synonyms, seniority equivalents. Maximise discovery while maintaining precision.
Respond ONLY with valid JSON:
{
  "job_titles": {"primary": ["string"], "seniority_variants": ["string"], "adjacent": ["string"]},
  "locations": {"primary": "string", "nearby": ["string"], "remote_ok": true, "expansion_suggestions": "string"},
  "skills": {"core": ["string"], "supporting": ["string"], "transferable": ["string"]},
  "companies": {"industries": ["string"], "company_types": ["string"], "include_suggestions": ["string"], "exclude_suggestions": ["string"]},
  "boolean_strings": {"primary": "string", "broad": "string", "narrow": "string", "github": "string", "stackoverflow": "string"},
  "filters": {"seniority": ["string"], "functions": ["string"], "experience_years_min": 2, "experience_years_max": 10},
  "regional_job_boards": {"recommended_regions": ["string"], "board_suggestions": ["string"]}
}"""

def build_search_params(provider: str, api_key: str, jd_analysis: Dict,
                         skill_matrix: Dict, location_hint: str = "") -> Optional[Dict]:
    ctx = {"jd_analysis": jd_analysis, "skill_matrix": skill_matrix, "location_hint": location_hint}
    return _ai_json(provider, api_key, _P3, f"Build sourcing parameters:\n\n{json.dumps(ctx, indent=2)}")

# ══════════════════════════════════════════════════════════════════════════════
# PROMPT 4 — CANDIDATE MATCH SCORER
# ══════════════════════════════════════════════════════════════════════════════
_P4 = """Score a candidate profile against a skill matrix. Return 0-100 match score.
Respond ONLY with valid JSON:
{
  "match_score": 0,
  "matched_skills": ["string"],
  "missing_skills": ["string"],
  "rationale": "string",
  "recommendation": "strong_match|good_match|potential|weak_match"
}"""

def score_candidate(provider: str, api_key: str, candidate_snippet: str,
                    skill_matrix: Dict) -> Optional[Dict]:
    ctx = {
        "candidate_profile": candidate_snippet,
        "skill_matrix": skill_matrix.get("skill_matrix", []),
        "non_negotiables": skill_matrix.get("non_negotiables", []),
    }
    return _ai_json(provider, api_key, _P4, json.dumps(ctx), max_tokens=512)

# ══════════════════════════════════════════════════════════════════════════════
# SEARCH REFINEMENT
# ══════════════════════════════════════════════════════════════════════════════
_P_REFINE = """A recruiter can't find the right candidates. Based on their feedback, suggest search changes.
Respond ONLY with valid JSON:
{
  "updated_titles": ["string"],
  "updated_skills": ["string"],
  "updated_boolean": "string",
  "updated_location": "string",
  "updated_seniority": "string",
  "reasoning": "string",
  "additional_sources": ["string"]
}"""

def refine_search(provider: str, api_key: str, current_filters: Dict,
                  user_feedback: str, results_so_far: int) -> Optional[Dict]:
    ctx = {"current_filters": current_filters, "user_feedback": user_feedback, "results_found": results_so_far}
    return _ai_json(provider, api_key, _P_REFINE, json.dumps(ctx, indent=2))

# ══════════════════════════════════════════════════════════════════════════════
# OUTREACH GENERATOR
# ══════════════════════════════════════════════════════════════════════════════
_P_OUTREACH = """Write a personalised recruiter outreach message. Personal, specific, not pushy. Clear CTA.
LinkedIn Connection Note: max 300 chars. InMail: up to 2000. Email: include subject.
Respond ONLY with valid JSON:
{"subject": "string or null", "message": "string", "character_count": 0}"""

def generate_outreach(provider: str, api_key: str, candidate: Dict,
                      jd_summary: str, tone: str, fmt: str) -> Optional[Dict]:
    ctx = {
        "candidate_name":     candidate.get("full_name", ""),
        "candidate_title":    candidate.get("current_title", ""),
        "candidate_location": candidate.get("location", ""),
        "candidate_skills":   candidate.get("skills", []),
        "job_summary":        jd_summary,
        "message_tone":       tone,
        "message_format":     fmt,
    }
    return _ai_json(provider, api_key, _P_OUTREACH, json.dumps(ctx, indent=2), max_tokens=1024)

# ══════════════════════════════════════════════════════════════════════════════
# FULL PIPELINE
# ══════════════════════════════════════════════════════════════════════════════
def run_full_jd_pipeline(provider: str, api_key: str,
                          jd_text: str, location_hint: str = "") -> Dict:
    """Run all 3 prompts in sequence. Returns partial results on failure."""
    results = {}
    with st.spinner("🧠 Analysing job description…"):
        jd_analysis = analyze_jd(provider, api_key, jd_text)
        if not jd_analysis:
            return {}
        results["jd_analysis"] = jd_analysis

    with st.spinner("⚖️ Building skill matrix…"):
        skill_matrix = build_skill_matrix(provider, api_key, jd_analysis)
        if not skill_matrix:
            return results
        results["skill_matrix"] = skill_matrix

    with st.spinner("🔍 Generating search parameters…"):
        search_params = build_search_params(
            provider, api_key, jd_analysis, skill_matrix, location_hint)
        if not search_params:
            return results
        results["search_params"] = search_params

    return results
