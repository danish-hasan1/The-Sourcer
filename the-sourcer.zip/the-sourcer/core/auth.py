"""
core/auth.py
Authentication logic for The Sourcer using Supabase Auth.
"""
import streamlit as st
from core.database import get_supabase, get_profile, get_api_keys
from typing import Optional, Dict


def sign_up(email: str, password: str, full_name: str) -> Dict:
    """Register a new user."""
    try:
        sb = get_supabase()
        res = sb.auth.sign_up({
            "email": email,
            "password": password,
            "options": {"data": {"full_name": full_name}}
        })
        if res.user:
            return {"success": True, "user": res.user}
        return {"success": False, "error": "Signup failed. Please try again."}
    except Exception as e:
        err = str(e)
        if "already registered" in err.lower() or "already exists" in err.lower():
            return {"success": False, "error": "This email is already registered. Please log in."}
        return {"success": False, "error": err}


def sign_in(email: str, password: str) -> Dict:
    """Log in an existing user."""
    try:
        sb = get_supabase()
        res = sb.auth.sign_in_with_password({"email": email, "password": password})
        if res.user and res.session:
            return {"success": True, "user": res.user, "session": res.session}
        return {"success": False, "error": "Invalid email or password."}
    except Exception as e:
        return {"success": False, "error": "Invalid email or password."}


def sign_out():
    """Log out the current user."""
    try:
        sb = get_supabase()
        sb.auth.sign_out()
    except Exception:
        pass
    # Clear session state
    for key in ["user", "profile", "api_keys", "supabase_client"]:
        st.session_state.pop(key, None)
    st.rerun()


def get_current_user() -> Optional[Dict]:
    """Return the current user from session state."""
    return st.session_state.get("user")


def is_authenticated() -> bool:
    return "user" in st.session_state and st.session_state.user is not None


def is_admin() -> bool:
    profile = st.session_state.get("profile", {})
    return profile.get("role") == "admin"


def require_auth():
    """Redirect to login if not authenticated. Call at top of every protected page."""
    if not is_authenticated():
        st.session_state["redirect_after_login"] = st.query_params.get("page", "")
        st.switch_page("pages/01_Login.py")


def load_user_session(user_id: str):
    """Load profile and API keys into session state."""
    if "profile" not in st.session_state or not st.session_state.profile:
        st.session_state.profile = get_profile(user_id)
    if "api_keys" not in st.session_state or not st.session_state.api_keys:
        st.session_state.api_keys = get_api_keys(user_id)


def reset_password(email: str) -> Dict:
    """Send password reset email."""
    try:
        sb = get_supabase()
        sb.auth.reset_password_email(email)
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": str(e)}


def get_anthropic_key() -> Optional[str]:
    """Get the user's Anthropic API key from session."""
    keys = st.session_state.get("api_keys", {})
    return keys.get("anthropic_key") or st.secrets.get("ANTHROPIC_KEY_DEFAULT", None)


def get_google_keys() -> Dict:
    """Get Google CSE credentials."""
    keys = st.session_state.get("api_keys", {})
    return {
        "cse_id": keys.get("google_cse_id", ""),
        "api_key": keys.get("google_api_key", ""),
    }


def get_github_token() -> Optional[str]:
    keys = st.session_state.get("api_keys", {})
    return keys.get("github_token", "")
