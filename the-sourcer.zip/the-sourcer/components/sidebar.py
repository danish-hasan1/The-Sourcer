"""
components/sidebar.py
Consistent sidebar navigation for all authenticated pages.
"""
import streamlit as st
from core.auth import sign_out, is_admin
from utils.helpers import inject_global_css


def render_sidebar():
    """Render the main navigation sidebar."""
    inject_global_css()

    with st.sidebar:
        # Brand
        st.markdown("""
        <div style="padding: 1rem 0 0.5rem;">
            <div style="font-size:1.3rem; font-weight:700; color:#14B8A6; letter-spacing:-0.02em;">
                The<span style="color:#F59E0B;">Sourcer</span>
            </div>
            <div style="font-size:0.7rem; color:#475569; letter-spacing:0.08em; text-transform:uppercase; margin-top:2px;">
                AI Talent Intelligence
            </div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("---")

        # Profile snippet
        profile = st.session_state.get("profile", {})
        name = profile.get("full_name", "Recruiter") or "Recruiter"
        role = profile.get("role", "user")
        st.markdown(f"""
        <div style="display:flex; align-items:center; gap:10px; padding: 8px 0; margin-bottom:8px;">
            <div style="width:36px; height:36px; border-radius:50%; background:linear-gradient(135deg,#0D9488,#F59E0B);
                        display:flex; align-items:center; justify-content:center; font-weight:700; color:white; font-size:14px; flex-shrink:0;">
                {name[0].upper()}
            </div>
            <div>
                <div style="font-size:13px; font-weight:600; color:#F1F5F9;">{name}</div>
                <div style="font-size:11px; color:#475569; text-transform:capitalize;">{role}</div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        # Navigation
        st.markdown('<div style="font-size:10px; color:#475569; text-transform:uppercase; letter-spacing:0.1em; font-weight:600; margin-bottom:6px;">MAIN</div>', unsafe_allow_html=True)

        if st.button("🏠  Dashboard", use_container_width=True, key="nav_dashboard"):
            st.switch_page("pages/03_Dashboard.py")

        if st.button("🔍  New Search", use_container_width=True, key="nav_search"):
            st.switch_page("pages/04_New_Search.py")

        if st.button("👥  Candidate Database", use_container_width=True, key="nav_candidates"):
            st.switch_page("pages/06_Candidate_Database.py")

        if st.button("🗂️  Saved Searches", use_container_width=True, key="nav_saved"):
            st.switch_page("pages/07_Saved_Searches.py")

        st.markdown("---")
        st.markdown('<div style="font-size:10px; color:#475569; text-transform:uppercase; letter-spacing:0.1em; font-weight:600; margin-bottom:6px;">TOOLS</div>', unsafe_allow_html=True)

        if st.button("✉️  Outreach", use_container_width=True, key="nav_outreach"):
            st.switch_page("pages/08_Outreach.py")

        if st.button("📄  JD Library", use_container_width=True, key="nav_jd"):
            st.switch_page("pages/07_Saved_Searches.py")

        st.markdown("---")
        st.markdown('<div style="font-size:10px; color:#475569; text-transform:uppercase; letter-spacing:0.1em; font-weight:600; margin-bottom:6px;">ACCOUNT</div>', unsafe_allow_html=True)

        if st.button("⚙️  Settings", use_container_width=True, key="nav_settings"):
            st.switch_page("pages/09_Settings.py")

        if is_admin():
            if st.button("🛡️  Admin Panel", use_container_width=True, key="nav_admin"):
                st.switch_page("pages/10_Admin.py")

        st.markdown("<div style='flex:1'></div>", unsafe_allow_html=True)

        # Sign out at the bottom
        st.markdown("---")
        if st.button("↩  Sign Out", use_container_width=True, key="nav_signout"):
            sign_out()
