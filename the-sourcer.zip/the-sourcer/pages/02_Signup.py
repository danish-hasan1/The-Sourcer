"""
pages/02_Signup.py — Create Account
"""
import streamlit as st
from core.auth import sign_up, sign_in, load_user_session
from utils.helpers import inject_global_css

st.set_page_config(page_title="Create Account — The Sourcer", page_icon="🎯", layout="centered", initial_sidebar_state="collapsed")
inject_global_css()

if "user" in st.session_state and st.session_state.user:
    st.switch_page("pages/03_Dashboard.py")

col1, col2, col3 = st.columns([1, 2, 1])
with col2:
    st.markdown("""
    <div style="text-align:center; margin-bottom: 2rem; margin-top: 2rem;">
        <div style="font-size:1.6rem; font-weight:800; color:#14B8A6; letter-spacing:-0.02em;">
            The<span style="color:#F59E0B;">Sourcer</span>
        </div>
        <div style="font-size:0.75rem; color:#475569; letter-spacing:0.08em; text-transform:uppercase;">
            AI Talent Intelligence
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("### Create your account")
    st.markdown('<div style="color:#64748B; font-size:0.88rem; margin-bottom:1.5rem;">Free to start. Your own API keys. Full control.</div>', unsafe_allow_html=True)

    with st.form("signup_form"):
        full_name = st.text_input("Full name", placeholder="Jane Smith")
        email = st.text_input("Work email", placeholder="you@company.com")
        password = st.text_input("Password", type="password", placeholder="At least 8 characters")
        confirm_pw = st.text_input("Confirm password", type="password", placeholder="Repeat password")

        st.markdown("""
        <div style="font-size:0.75rem; color:#475569; margin: 8px 0;">
            By creating an account, you agree that all candidate sourcing is done via publicly
            available information in compliance with applicable platform terms.
        </div>
        """, unsafe_allow_html=True)

        submitted = st.form_submit_button("Create Account →", use_container_width=True, type="primary")

        if submitted:
            if not all([full_name, email, password, confirm_pw]):
                st.error("Please fill in all fields.")
            elif len(password) < 8:
                st.error("Password must be at least 8 characters.")
            elif password != confirm_pw:
                st.error("Passwords do not match.")
            elif "@" not in email:
                st.error("Please enter a valid email address.")
            else:
                with st.spinner("Creating your account..."):
                    result = sign_up(email, password, full_name)
                if result["success"]:
                    # Auto-login after signup
                    login_result = sign_in(email, password)
                    if login_result["success"]:
                        st.session_state.user = login_result["user"]
                        st.session_state.session = login_result["session"]
                        load_user_session(login_result["user"].id)
                        st.success("Account created! Welcome to The Sourcer 🎉")
                        st.switch_page("pages/03_Dashboard.py")
                    else:
                        st.success("Account created! Please sign in.")
                        st.switch_page("pages/01_Login.py")
                else:
                    st.error(result["error"])

    st.markdown("---")

    col_a, col_b = st.columns(2)
    with col_a:
        if st.button("Already have an account? Sign in", use_container_width=True):
            st.switch_page("pages/01_Login.py")
    with col_b:
        if st.button("← Back to home", use_container_width=True):
            st.switch_page("app.py")
