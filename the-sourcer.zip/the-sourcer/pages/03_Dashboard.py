"""
pages/03_Dashboard.py — Main Dashboard
"""
import streamlit as st
from core.auth import require_auth, load_user_session
from core.database import get_candidate_stats, get_searches, get_jd_library, get_candidates
from components.sidebar import render_sidebar
from components.onboarding import render_onboarding
from utils.helpers import inject_global_css, empty_state
import plotly.graph_objects as go

st.set_page_config(page_title="Dashboard — The Sourcer", page_icon="🎯", layout="wide")
inject_global_css()
require_auth()

user = st.session_state.user
load_user_session(user.id)

render_sidebar()

# Show onboarding if first time
if render_onboarding():
    st.stop()

profile = st.session_state.get("profile", {})
name = profile.get("full_name", "there") or "there"
first_name = name.split()[0] if name else "there"

# ── Header ────────────────────────────────────────────────────────────────────
st.markdown(f"""
<div style="padding: 1.5rem 0 1rem;">
    <div style="font-size:1.6rem; font-weight:800; color:#F1F5F9;">
        Good day, <span style="color:#14B8A6;">{first_name}</span> 👋
    </div>
    <div style="color:#64748B; font-size:0.88rem; margin-top:4px;">
        Here's what's happening across your searches and pipeline.
    </div>
</div>
""", unsafe_allow_html=True)

# ── Fetch data ─────────────────────────────────────────────────────────────────
stats = get_candidate_stats(user.id)
searches = get_searches(user.id)
jd_library = get_jd_library(user.id)

# ── API Key warning ────────────────────────────────────────────────────────────
api_keys = st.session_state.get("api_keys", {})
if not api_keys.get("anthropic_key"):
    st.warning("⚠️ **API keys not configured.** Go to **Settings** to add your Anthropic and Google Search API keys before running searches.", icon="🔑")
    if st.button("⚙️ Go to Settings"):
        st.switch_page("pages/09_Settings.py")
    st.markdown("---")

# ── Stats Row ──────────────────────────────────────────────────────────────────
col1, col2, col3, col4, col5 = st.columns(5)
with col1:
    st.metric("Total Candidates", stats["total"])
with col2:
    st.metric("Sourced", stats["sourced"])
with col3:
    st.metric("Reviewed", stats["reviewed"])
with col4:
    st.metric("Contacted", stats["contacted"])
with col5:
    st.metric("Interviews", stats["interview"])

st.markdown("---")

# ── Main grid ──────────────────────────────────────────────────────────────────
left, right = st.columns([3, 2], gap="large")

with left:
    # Recent searches
    st.markdown("### 🔍 Recent Searches")
    if searches:
        for s in searches[:5]:
            jd_title = (s.get("jd_library") or {}).get("title", "Untitled JD") if isinstance(s.get("jd_library"), dict) else "Untitled JD"
            result_count = s.get("result_count", 0)
            status = s.get("status", "completed")
            status_colors = {"completed": "#10B981", "running": "#F59E0B", "draft": "#94A3B8", "paused": "#6366F1"}
            sc = status_colors.get(status, "#94A3B8")

            with st.container():
                st.markdown(f"""
                <div style="background:#1E293B; border:1px solid #334155; border-radius:10px;
                            padding:14px 18px; margin-bottom:8px; cursor:pointer;"
                     onmouseover="this.style.borderColor='#0D9488'"
                     onmouseout="this.style.borderColor='#334155'">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <div>
                            <div style="font-weight:600; color:#F1F5F9; font-size:0.95rem;">{s.get('name','Unnamed Search')}</div>
                            <div style="color:#64748B; font-size:0.78rem; margin-top:2px;">
                                {jd_title} · {result_count} candidates found
                            </div>
                        </div>
                        <span style="background:{sc}22; color:{sc}; border-radius:999px;
                                     padding:2px 10px; font-size:11px; font-weight:600;">
                            {status.title()}
                        </span>
                    </div>
                </div>
                """, unsafe_allow_html=True)

            col_a, col_b = st.columns([1, 1])
            with col_a:
                if st.button("▶ Resume", key=f"resume_{s['id']}", use_container_width=True):
                    st.session_state["resume_search"] = s
                    st.switch_page("pages/04_New_Search.py")
            with col_b:
                if st.button("👥 View Candidates", key=f"view_{s['id']}", use_container_width=True):
                    st.session_state["filter_search_id"] = s["id"]
                    st.switch_page("pages/06_Candidate_Database.py")
    else:
        empty_state("🔍", "No searches yet", "Start your first search to see results here.")
        if st.button("🚀 Start First Search", type="primary"):
            st.switch_page("pages/04_New_Search.py")

with right:
    # Pipeline donut chart
    if stats["total"] > 0:
        st.markdown("### 📊 Pipeline Overview")
        stages = ["Sourced", "Reviewed", "Contacted", "Responded", "Interview"]
        values = [stats["sourced"], stats["reviewed"], stats["contacted"], stats["responded"], stats["interview"]]
        colors = ["#7DCFFF", "#86EFAC", "#FCD34D", "#A5B4FC", "#F0ABFC"]

        fig = go.Figure(data=[go.Pie(
            labels=stages,
            values=values,
            hole=0.65,
            marker_colors=colors,
            textinfo="none",
            hovertemplate="<b>%{label}</b><br>%{value} candidates<extra></extra>",
        )])
        fig.update_layout(
            showlegend=True,
            legend=dict(orientation="v", x=1.05, font=dict(color="#94A3B8", size=11)),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            margin=dict(t=10, b=10, l=10, r=80),
            height=220,
            annotations=[dict(
                text=f"<b>{stats['total']}</b><br><span style='font-size:10px'>total</span>",
                x=0.5, y=0.5, font_size=18, font_color="#F1F5F9",
                showarrow=False
            )]
        )
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
    else:
        st.markdown("### 📊 Pipeline Overview")
        empty_state("📊", "Pipeline empty", "Save candidates to see your pipeline.")

    st.markdown("---")

    # JD Library quick access
    st.markdown("### 📄 JD Library")
    if jd_library:
        for jd in jd_library[:4]:
            col_j1, col_j2 = st.columns([3, 1])
            with col_j1:
                st.markdown(f"""
                <div style="color:#F1F5F9; font-size:0.88rem; font-weight:500;">
                    {jd.get('title','Untitled')}
                </div>
                """, unsafe_allow_html=True)
            with col_j2:
                if st.button("Use", key=f"usejd_{jd['id']}", use_container_width=True):
                    st.session_state["prefill_jd"] = jd
                    st.switch_page("pages/04_New_Search.py")
    else:
        st.markdown('<div style="color:#475569; font-size:0.85rem;">No saved JDs yet.</div>', unsafe_allow_html=True)

    if st.button("📄 JD Library →", use_container_width=True):
        st.switch_page("pages/07_Saved_Searches.py")

st.markdown("---")

# Quick action row
st.markdown("### ⚡ Quick Actions")
q1, q2, q3, q4 = st.columns(4)
with q1:
    if st.button("🔍 New Search", use_container_width=True, type="primary"):
        st.switch_page("pages/04_New_Search.py")
with q2:
    if st.button("👥 Candidate Database", use_container_width=True):
        st.switch_page("pages/06_Candidate_Database.py")
with q3:
    if st.button("✉️ Outreach", use_container_width=True):
        st.switch_page("pages/08_Outreach.py")
with q4:
    if st.button("⚙️ Settings", use_container_width=True):
        st.switch_page("pages/09_Settings.py")
